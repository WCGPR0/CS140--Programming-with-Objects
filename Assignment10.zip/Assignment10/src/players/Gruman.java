/** 
 * A creature that is supposedly an enemy of the human objects and has life, strength, and sacks of gold. It's objective is to not lose their sacks of gold and to damage the humans.
 * @author Victor Wu
 * Section 55 - CS140
 */

package players;

import java.io.ObjectStreamClass;
//import java.util.logging.*;

import utility.SingleRandom;
import repository.*;
import java.io.IOException;

public class Gruman extends Player // implements java.io.Serializable
{

	// Instance class variables
	public final static int MAX_SACKS_TO_START;
	// private int myID = (int)serialVersionUID;
	/*
	 * This Human's debug logger
	 */
	/* private Logger log; */
	/*
	 * Configures logger output file
	 */
	/* private Handler handler; */
	// private final static long serialVersionUID;
	/**
	 * Static initialization
	 */
	static
	{
		// serialVersionUID =
		// ObjectStreamClass.lookup(Gruman.class).getSerialVersionUID();
		MAX_SACKS_TO_START = 10;
	}

	// Constructors
	/**
	 * Constructs an explicit constructor for a Gruman object
	 * 
	 * @param myName
	 *                of Gruman
	 * @param sacks
	 *                of sacks for Gruman
	 * @param health
	 *                of max and initial health for Gruman
	 * @param strength
	 *                of Gruman
	 */
	public Gruman(String name, int sacks, double health, double strength)
	{
		super(name, sacks, strength);
		setHealth(Math.max(Math.min(health, MAX_HEALTH_POSSIBLE), 1));
		/*
		 * try { handler = new FileHandler("Human" + myID + ".txt");
		 * handler.setFormatter(new SimpleFormatter()); } catch
		 * (IOException e) { e.printStackTrace(); } log =
		 * Logger.getLogger("Human"+ myID); log.addHandler(handler);
		 * log.setLevel(Level.ALL); //log.setLevel(Level.OFF);
		 */// TURNS LOGGER OFF
	}

	/**
	 * Constructs a partially explicit constructor for a Gruman object with
	 * random sacks
	 * 
	 * @param myName
	 *                of Gruman
	 * @param health
	 *                of max and initial health for Gruman
	 * @param strength
	 *                of Gruman
	 */
	public Gruman(String myName, double health, double strength)
	{
		this(myName, SingleRandom.getInstance().nextInt(
				MAX_SACKS_TO_START), strength, health);
	}

	/**
	 * Constructs a partially explicit constructor for a Gruman object with
	 * 0 sacks, random health and strength
	 * 
	 * @param myName
	 *                of Gruman
	 */
	public Gruman(String myName)
	{
		this(myName, SingleRandom.getInstance().nextInt(
				(int) MAX_SACKS_TO_START), SingleRandom
				.getInstance().nextInt((int) HEALTH_SCALE),
				SingleRandom.getInstance().nextInt(
						(int) STRENGTH_SCALE));
	}

	/**
	 * Constructs a Gruman named "Anonymous" and has random sacks, health
	 * and strength
	 */
	public Gruman()
	{

		this(GrumanNames.getInstance().takeNames());
	}

	// Accessors
	/**
	 * Gets the terrify power of Gruman
	 * 
	 * @return the poke power from formula: strength / HEALTH_SCALE * health
	 */
	public double terrifyHuman()
	{
		return getStrength() / HEALTH_SCALE * getHealth();

	}

	// Mutators
	/**
	 * Receives damage and loses health and strength
	 * 
	 * @param force
	 *                power of Gruman's terror
	 */
	public void sufferPoke(double force)
	{
		setHealth(Math.max(getHealth() - force, 0));
		setStrength(Math.max(getStrength() - (force / STRENGTH_SCALE),
				0));
	}

	/**
	 * Adjusts the sacks to a new value
	 * 
	 * @param sacks
	 *                value to be the new sacks
	 */
}