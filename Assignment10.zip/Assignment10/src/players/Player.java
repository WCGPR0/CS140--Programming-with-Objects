/** 
 * A superclass of the Gruman and Human class that outlines a Player
 * @author Victor Wu
 * Section 55 - CS140
 */

package players;

import java.io.ObjectStreamClass;

public class Player
{
	// Instance Class variables
	private String name;
	private double health;
	private int sacks;
	private double strength;

	// Final constants
	public final static double HEALTH_SCALE;
	public final int MAX_HEALTH_POSSIBLE = (int) HEALTH_SCALE;
	public final double MAX_HEALTH;
	public final static double STRENGTH_SCALE;
	public final static int MAX_STRENGTH_POSSIBLE;
	public final double MAX_STRENGTH;
	// Static initialization
	static
	{
		STRENGTH_SCALE = 10.0;
		MAX_STRENGTH_POSSIBLE = (int) STRENGTH_SCALE;
		HEALTH_SCALE = 100.0;
	}

	public Player(String name, int sacks, double strength)
	{
		this.name = name;
		this.sacks = Math.max(sacks, 0);
		this.strength = Math.max(
				Math.min(strength, MAX_STRENGTH_POSSIBLE), 1);
		this.health = Math
				.max(Math.min(health, MAX_HEALTH_POSSIBLE), 1);
		MAX_HEALTH = Math.max(Math.min(health, MAX_HEALTH_POSSIBLE), 1);
		MAX_STRENGTH = Math.max(
				Math.min(strength, MAX_STRENGTH_POSSIBLE), 1);
	}

	// Accessors
	/**
	 * Gets the current name of Player
	 * 
	 * @return the current name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * Gets the current sacks of Player
	 * 
	 * @return the current sacks
	 */
	public int getSacks()
	{
		return sacks;
	}

	/**
	 * Gets the current strength of Player
	 * 
	 * @return the current strength
	 */
	public double getStrength()
	{
		return strength;
	}

	/**
	 * Gets the current health of Player
	 * 
	 * @return the current health
	 */
	public double getHealth()
	{
		return health;
	}

	/**
	 * Gets the poke power of Player
	 * 
	 * @return the poke power from formula: strength / HEALTH_SCALE * health
	 */

	// Predicate methods
	/**
	 * Checks if Player has any available sacks
	 * 
	 * @return the boolean of (sacks > 0)
	 */
	public boolean hasSacks()
	{
		return (sacks > 0);
	}

	/**
	 * Checks if Player has any available strength
	 * 
	 * @return the boolean of (strength > 0)
	 */
	public boolean hasStrength()
	{
		return (strength > 0);
	}

	/**
	 * Checks if Player has any available health
	 * 
	 * @return the boolean of (health > 0)
	 */
	public boolean hasHealth()
	{
		return (health > 0);
	}

	// Mutators
	/**
	 * Increment sacks by one
	 */
	public void incrementSacks()
	{
		sacks++;
	}

	/**
	 * Decrement sacks by one
	 */
	public void decrementSacks()
	{
		sacks--;
	}

	/**
	 * Adjusts the sacks to a new value
	 * 
	 * @param sacks
	 *                value to be the new sacks
	 */
	public void setSacks(int sacks)
	{
		this.sacks = Math.max(sacks, 0);
	}

	/**
	 * Adjusts the sacks to a new value
	 * 
	 * @param health
	 *                value to be the new amount for health
	 */
	public void setHealth(double health)
	{
		this.health = Math.max(Math.min(health, MAX_HEALTH), 0);
	}

	/**
	 * Adjusts the strength to a new value
	 * 
	 * @param strength
	 *                value to be the new amount of strength
	 */
	public void setStrength(double strength)
	{
		this.strength = Math.max(Math.min(strength, MAX_STRENGTH), 0);
	}

	/**
	 * Resets strength to MAX_HEALTH
	 */
	public void resetHealth()
	{
		health = MAX_HEALTH;
	}

	/**
	 * Resets strength to MAX_STRENGTH
	 */
	public void resetStrength()
	{
		strength = MAX_STRENGTH;
	}

	/**
	 * Adds health by: MAX_HEALTH / HEALTH_SCALE
	 */
	public void restoreHealth()
	{
		health = Math.max(Math.min(health
				+ (MAX_HEALTH / STRENGTH_SCALE), MAX_HEALTH), 0);
	}

	/**
	 * Adds strength by: MAX_STRENGTH / 2*STRENGTH_SCALE
	 */
	public void restoreStrength()
	{
		strength = Math.max(Math.min(strength
				+ ((MAX_STRENGTH / 2) / STRENGTH_SCALE),
				MAX_STRENGTH), 0);
	}

	/**
	 * Reduces strength by an additional MAX_STRENGTH / 2*STRENGTH_SCALE
	 */
	public void reduceStrength()
	{
		strength = Math.max(Math.min(strength
				- ((MAX_STRENGTH / 2) / STRENGTH_SCALE),
				MAX_STRENGTH), 0);
	}

	// Overloaded methods
	/**
	 * Gets info about Human
	 * 
	 * @return Name, Sacks, Strength, Health of the Human
	 */
	public String toString()
	{
		return String.format(
				"Name: %s%nSacks: %s%nStrength: %.1f%nHealth: %.1f",
				getClass().getName(), sacks, strength, health);
	}
}
