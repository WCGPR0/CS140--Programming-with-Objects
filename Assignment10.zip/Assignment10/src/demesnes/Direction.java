/** A class that represents the Direction on a grid.
 * @author Victor Wu
 * Section 55- CS 140
 */
package demesnes;

public enum Direction
{
NORTH(0,1){
public Direction next(){
return EAST;
}
},
EAST(1,0){
public Direction next(){
return SOUTH;	
}
},
SOUTH(0,-1){
public Direction next(){
return WEST;	
}
},
WEST(-1,0){
public Direction next(){
return NORTH;	
}
};
private int verticalOffset;
private int horizontalOffset;
/**
 * Explicit constructor that sets the coordinates
 * @param int horizontal offset
 * @param int vertical offset
 */
private Direction(int horizontalOffset, int verticalOffset){
this.horizontalOffset = horizontalOffset;
this.verticalOffset = verticalOffset;
}

//Accessors
/**
 * Gets the Horizontal Offset
 * @return int horizontal offset
 */
public int getHorizontalOffset(){
return horizontalOffset;
}
/**
 * gets the Vertical Offset
 * @return int vertical offset
 */
public int getVerticalOffset(){
return verticalOffset;
}
/**
 * gets the opposite Direction
 * @return Direction in the other direction
 */
public Direction opposite(){
	return next().next();
}
@Override
public String toString(){
	return String.format("%s",name().toLowerCase());
}
public abstract Direction next();
}
