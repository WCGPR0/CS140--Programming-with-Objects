package demesnes;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import players.*;
import utility.SingleRandom;
import wall.Wall;

public class Maze
{
//Constant variables
public final int 
NONE = -1,
MAX_NUMBERS_CHAMBERS=5,
GRUMAN_ODDS=3,
DOOR_ODDS=3;

//Class variables
private int chambersLeft,counter;
private Logger logger;
private HashMap<Location, Chamber> map;
private ArrayList<Gruman> grumans;

//Instance of this class
private static Maze maze = new Maze();
/**
 * Default Constructor
 */
public Maze(){
	setUpLogging();
	int grumanCount = 0;
	int grumanID;
	ArrayList<Location> toDoList = new ArrayList<Location>();
	map = new HashMap<Location, Chamber>();
	grumans = new ArrayList<Gruman>();
	Chamber someChamber = createEntranceChamber(toDoList);
	addToMap(map, someChamber);
	while (!toDoList.isEmpty()) {grumanID = 0; if ((SingleRandom.getInstance().nextInt(GRUMAN_ODDS)+1) > 0)
		{grumans.add(new Gruman()); grumanID = grumanCount; grumanCount++;}
	createRemainingChambers(toDoList, grumanID);
	}
showFinishedMaze(maze); 
	}


/**
 * Adds default location (0,0) to toDoList
 * @param ArrayList<Location> toDoList to be added to
 */
public Chamber createEntranceChamber(ArrayList<Location> toDoList){
	Chamber myChamber = new Chamber();
	chambersLeft--;
	for (Direction d: Direction.values())
	{
		if (myChamber.hasDoor(d))
				{
			toDoList.add(new Location(new Location(),d));
				}
	}
	return myChamber;
}

/**
 * Creates the remainder chambers
 * @param ArrayList<Location> of the toDoList
 * @param int type of the grumanID
 */
public Chamber createRemainingChambers(ArrayList<Location> toDoList, int grumanID){
	Chamber currentChamber = map.get(toDoList.get(counter));
	toDoList.remove(counter);
	EnumMap<Direction, Wall> someEnumMap = new EnumMap<Direction,Wall>(Direction.class);
	for (Direction d : Direction.values())
	{
		if (map.get(new Location(currentChamber.getLocation(), d)) instanceof Chamber)
		{
			if (map.get(new Location(currentChamber.getLocation(), d)).hasDoor(d))
			someEnumMap.put(d, Wall.DOOR);
			else someEnumMap.put(d, Wall.BLANK);
		}
		else if ((chambersLeft > 0) && (SingleRandom.getInstance().nextInt(DOOR_ODDS) > 0))
		{
			someEnumMap.put(d, Wall.DOOR);
			map.put(new Location(currentChamber.getLocation(), d),new Chamber());
			if (!toDoList.contains(new Location(currentChamber.getLocation()))) 
				{toDoList.add(new Location(currentChamber.getLocation())); chambersLeft--;}
		}
		else 			someEnumMap.put(d, Wall.DOOR);
	}
	return new Chamber(someEnumMap, currentChamber.getLocation(), grumanID);
}

/**
 * Adds to the Map
 * @param HashMap<Location, Chamber> 
 * @param Chamber 
 */
public void addToMap(HashMap<Location, Chamber> map, Chamber someChamber){
	map.put(someChamber.getLocation(), someChamber);
	counter++;
}

/**
 * Shows the final maze
 * @param Maze to be shown
 */
public void showFinishedMaze(Maze maze){
	logger.info(maze.toString());
}

//Predicate methods
/**
 * a predicate that determines if the Maze contains a chamber in a given location
 * @param Location of where the Maze checks for chamber
 * @return true if there is a chamber else false
 */
public boolean hasChamber (Location location)
{
	return map.get(location) instanceof Chamber;
}

/**
 * a predicate that determines if there is a gruman given a Chamber
 * @param Chamber type of chamber to search for grumans
 * @return true if there is atleast one gruman
 */
public boolean hasGruman(Chamber chamber){
	return chamber.hasGruman();
}

//Accessor Methods
/**
 * Gets the Chamber at a given location
 * @param Location to search
 * @return Chamber that is retrieved from Location
 */
public Chamber getChamber(Location location){
	return map.get(location);
}
public Set<Location> getKeySet(){
	return map.keySet();
}

/**
 * Sets up the logger
 */
public void setUpLogging(){
	logger = Logger.getLogger(Maze.class.getName());
	//For fixed tests
	SingleRandom.getInstance().setSeed(1601);
	logger.setLevel(Level.ALL);
	counter = 0;
	chambersLeft = MAX_NUMBERS_CHAMBERS;
}

	
}
