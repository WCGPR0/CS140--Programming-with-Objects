/** A class that represents each chamber in the maze
 * @author Victor Wu
 * Section 55- CS 140
 */
//As long as any form of Location be returned, it is fine - whether it is an address or a deep copy
package demesnes;

import java.util.EnumMap;
import java.util.Random;

import wall.Wall;


public class Chamber
{
//Constant class variables
public static final int NONE = -1;
//Instance variables
private boolean visited;
private Location location;
private int grumanID;
private EnumMap<Direction, Wall> walls;

/**
 * Default Constructor that initializes the location as (0,0), visited as false, and grumanID as 0
 */
public Chamber(){
	location = new Location();
	visited = false;
	grumanID = 0;
	walls = new EnumMap<Direction,Wall>(Direction.class);
//Sets surrounding wall of original to blank
	for (Direction direction : Direction.values())
	{
		walls.put(direction, Wall.BLANK);
	}
int someWall = new Random().nextInt(3);
Direction someDirection;
if (someWall == 0) someDirection = Direction.WEST;
else if (someWall == 1) someDirection = Direction.NORTH;
else if (someWall == 2) someDirection = Direction.EAST;
else someDirection = Direction.SOUTH;
walls.put(someDirection, Wall.DOOR); }

/**
 * Partially Explicit Constructor that initializes the location, grumanID and visited as false
 * @param location Location location to be placed on the grid
 * @param grumanID int number of grumans in a particular place
 */
public Chamber(Location location, int grumanID)
{
	this.location = location;
	visited = false;
	this.grumanID = grumanID;
}

/**
 * Explicit Constructor that create all the other chambers in the maze
 * @param EnumMap type of walls to be set
 * @param Location type for the location
 * @param int variable to set the grumanID
 */
public Chamber(EnumMap walls, Location location, int grumanID)
{
	this(location, grumanID);
	this.walls = walls;
}


//Accessors
/**
 * Gets the location
 * @return Location location
 */
public Location getLocation(){
	return location;
}
/**
 * Gets the Gruman ID
 * @return int grumanID
 */
public int getGrumanID(){
	return grumanID;
}
/**
 * Gets the type of wall at the given direction
 * @param Direction type of key to check
 * @return Wall type at given Direction
 */
public Wall getWall(Direction someDirection){
	return walls.get(someDirection);
}
//Predicate Methods
/**
 * Checks if it's visited
 * @return boolean hasVisited if true else false
 */
public boolean hasVisited(){
	return visited;
}
/**
 * Checks if there's Gruman
 * @return boolean if there's more than one gruman, else false
 */
public boolean hasGruman(){
	return grumanID > 0;
}
/**
 * Checks if it's at (0,)
 * @return boolean true if it's at the starting location, else false
 */
public boolean isOrigin(){
	return ((location.getColumn() == 0) && (location.getRow() == 0));
}
/**
 * Checks if there is a door at the given direction
 * @param Direction type for the key to check
 * @return true if there is a door else false
 */
public boolean hasDoor(Direction someDirection)
{
return walls.get(someDirection).equals(Wall.DOOR);
}

//Mutators
/**
 * Sets visited as true
 */
public void setVisited(){
	visited = true;
}


@Override
public String toString(){
	String string1 = String.format("Location: %s\nGrumanID: %d\nVisited: %b\nHas Gruman:%b\nIs at Origin: %b", getLocation().toString(), getGrumanID(), hasVisited(), hasGruman(), isOrigin());
	String string2 = "\n";
	for (Direction d: Direction.values())
	{
		string2+=d.toString() + ": ";
		try {
			if (walls.get(d).hasDoor())
				string2+= "Door \n";
			else if (!(walls.get(d).hasDoor()))
				string2+= "Blank \n";
			else string2+= walls.get(d).toString();
		;}
		catch (Exception E){ string2+="null \n"; } 
	}
	return string2 + string1;
}
}
