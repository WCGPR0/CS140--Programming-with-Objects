/** A class that represents the location of the grid and also whether the path is accessible.
 * @author Victor Wu
 * Section 55- CS 140
 */

//Location class is an immutable object because it's members can't be changed
//Because we made copy constructors, therefore we don't need clone methods

package demesnes;

public class Location
{
//Instance variables
private int column, row;
//Constructors
/**
 * Default Constructor that initializes column and row as 0
 */
public Location()
{
	column = 0;
	row = 0;
}
/**
 * Explicit Constructor that initializes column and row
 * @param column the column to set Location as
 * @param row the row to set Location as
 */
public Location(int column, int row)
{
	this.column = column;
	this.row = row;
}
/**
 * Copy Constructor that creates a new Location with the same column and row
 * @param location the Location to be copied from
 */
public Location(Location location)
{
	column = location.column;
	row = location.row;
}
/**
 * Copy Constructor that also sets neighboring walls
 * @param location the Location to be copied from
 * @param travelDirection the Direction
 */
public Location(Location location, Direction travelDirection)
{
	column = location.column + travelDirection.getHorizontalOffset();
	row = location.row + travelDirection.getVerticalOffset();
}

//Accessors
/**
 * Gets the Column
 * @return int of column
 */
public int getColumn (){
	return column;
}
/**
 * Gets the Row
 * @return int of row
 */
public int getRow(){
	return row;
}
//Predicate methods
/**
 * Checks if it's at the origin
 * @return true if at (0,0) else false
 */
public boolean isOrigin(){
	return (column == 0) && (row == 0);
}
@Override
public boolean equals(Object obj){
	return column == (((Location)obj).getColumn()) && (row == ((Location)obj).getRow());
}
@Override
public int hashCode()
{
	int someNum = getColumn() * getRow();
	return (int) (someNum ^ (someNum >>> 32)) * 1601 + (isOrigin() ? 1 : 0); //1601 is a prime constant
}
@Override
public String toString()
{
return String.format("%s: ( %d,  %d)", getClass(), column, row, isOrigin());	
}

}
