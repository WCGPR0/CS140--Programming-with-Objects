package wall;


public enum Wall

{ BLANK {
		@Override
		public boolean hasDoor()
		{
			return false;
		}
	}, DOOR {
		@Override
		public boolean hasDoor()
		{
			return true;
		}
	}; 
	public abstract boolean hasDoor();
	public String toString(){
		return String.format("%s",name().toLowerCase());}
}



