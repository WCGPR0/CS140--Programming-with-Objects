/**
 * This class contains names to use. 
 * @author Victor Wu
 * Section 55- CS 140
 */

package repository;

import java.io.ObjectStreamClass;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import old_players.Gruman;

import utility.SingleRandom;

public class Names implements java.io.Serializable
{
	// Constant and static variables
	/**
	 * The string array of some preset names
	 */
	final String[] NAMES;
	/**
	 * The amount of names
	 */
	final int MAX_NAMES_TO_START;
	// Static variables
	/**
	 * A private instance of this class
	 */
	private final static long serialVersionUID;
	/**
	 * Static intialization
	 */
	static
	{
		serialVersionUID = ObjectStreamClass.lookup(Names.class)
				.getSerialVersionUID();
	}
	/**
	 * An Arraylist object
	 */
	private ArrayList<String> names;

	/**
	 * Default constructor that constructs the Arraylist names as array
	 * NAMES
	 */
	public Names(String[] stringArray)
	{
		NAMES = stringArray;
		MAX_NAMES_TO_START = NAMES.length;
		names = new ArrayList(Arrays.asList(NAMES));
	}

	// Accessors
	/**
	 * Method that returns number of names in the array
	 * 
	 * @return an @int of {@value} MAX_NAMES_LENGTH
	 */

	public int getMaxNamesToStart()
	{
		return MAX_NAMES_TO_START;
	}

	/**
	 * Method that returns number of names in the ArrayList
	 * 
	 * @return an int of the size of names
	 */
	public int getCurrentNumberOfNames()
	{
		return names.size();
	}

	/**
	 * Method when given an index, returns the name at that index
	 * 
	 * @param the
	 *                index for the element of names
	 * @return the String element found in names
	 */
	public String getName(int someIndex)
	{
		return names.get(someIndex);
	}

	/**
	 * Method when given a name, returns the index of that name
	 * 
	 * @param a
	 *                String that will be searched in names
	 * @return the index number of the matching String in names with the
	 *         parameter, else it'll return -1
	 */
	public int findName(String someName)
	{
		for (int i = 0; i < names.size(); i++)
		{
			if (names.get(i) == someName)
				return i;
		}
		return -1;
	}

	/**
	 * Method when given a name, returns whether or not the name is in the
	 * names
	 * 
	 * @param a
	 *                String that will be searched in the names
	 */
	public boolean hasName(String someName)
	{
		for (int i = 0; i < names.size(); i++)
		{
			if (names.get(i) == someName)
				return true;
		}
		return false;
	}

	/**
	 * Method that returns whether or not there are any names in names
	 * 
	 * @return true if names is not empty, else false
	 */
	public boolean hasNames()
	{
		for (int i = 0; i < names.size(); i++)
		{
			if (names.get(i) != "")
				return true;
		}
		return false;
	}

	/**
	 * Method that randomly returns a name found in names, and removes it
	 * from the names, else resets it
	 * 
	 * @return a random String name in names
	 */
	public String takeNames()
	{
		if (this.hasNames())
		{
			int tempInt = SingleRandom.getInstance().nextInt(
					names.size());
			String tempString = names.get(tempInt);
			names.remove(tempInt);
			return tempString;
		} else
			this.resetNames();
		return null;
	}

	/**
	 * Method that returns a string containing all the names currently in
	 * the ArrayList
	 */
	public String toString()
	{
		return getClass().getName();
	}

	// Mutators
	/**
	 * Method when given a name, adds the name to the ArrayList
	 * 
	 * @param someName
	 *                , a String to be added
	 */
	public void addName(String someName)
	{
		names.add(someName);
	}

	/**
	 * Method when given an index and a new name, replaces the old name at
	 * the given index of the ArrayList with the new name
	 * 
	 * @param someIndex
	 *                , an int for the index of the element to be replaced
	 * @param someName
	 *                , a String to replace the old String
	 */
	public void replaceName(int someIndex, String someName)
	{
		names.set(someIndex, someName);
	}

	/**
	 * Method when given an old name that is in the ArrayList and a new
	 * name, replace the old name in the ArrayList with the new name
	 * 
	 * @param someOldName
	 *                ,a String that will be searched in the names
	 * @param someNewName
	 *                ,a String that will replace the old String
	 */
	public void replaceName(String someOldName, String someNewName)
	{
		names.set(this.findName(someOldName), someNewName);
	}

	/**
	 * Method that removes all the names in the ArrayList
	 */

	public void eraseNames()
	{
		names.clear();
	}

	/**
	 * Method that re-instantiate the names ArrayList and initialize it to
	 * the Names in the arrray
	 */

	public void resetNames()
	{
		names = new ArrayList(Arrays.asList(NAMES));
	}

}
