package loops_and_arrays;

public class StringArrayAnalyzer extends StringArrayStats
{

	public StringArrayAnalyzer(String[] array)
	{
		super(array);
	}

	public StringArrayStats analyze(String[] array)
	{
		for (int i = 0; i < array.length - 1; i++)
		{
			if (minStringLength < array[i].length())
			{
				indexLastMin = i;
				minStringLength = array[i].length();
				lastStringWithMinLength = array[i];
			}
			if (maxStringLength > array[i].length())
			{
				indexLastMax = i;
				maxStringLength = array[i].length();
				lastStringWithMaxLength = array[i];
			}
		}
		for (int i = array.length - 1; i > 0; i--)
		{
			if (minStringLength <= array[i].length())
			{
				indexFirstMin = i;
				firstStringWithMinLength = array[i];
			}
			if (maxStringLength >= array[i].length())
			{
				indexFirstMax = i;
				firstStringWithMaxLength = array[i];
			}
		}
		return (StringArrayStats) this;
	}

}
