package loops_and_arrays;

public class StringArrayStats
{
	/** length of the shortest String(s) in the array */
	protected int minStringLength,
	/** length of the longest String(s) in the array */
	maxStringLength,
	/** the index in the array of that first shortest String */
	indexFirstMin,
	/** the index in the array of that last shortest String */
	indexLastMin,
	/** the index in the array of that first largest String */
	indexFirstMax,
	/** the index in the array of that last largest String */
	indexLastMax;
	/** the first String in the array that has the shortest length */
	String firstStringWithMinLength,
	/** the last String in the array that has the shortest length */
	lastStringWithMinLength,
	/** the first String in the array that has the largest length */
	firstStringWithMaxLength,
	/** the last String in the array that has the largest length */
	lastStringWithMaxLength;
	/** average length of all the Strings */
	protected double averageLength,
	/** the median length of all the Strings */
	medianLength;

	public StringArrayStats(String[] array)
	{
		minStringLength = array[0].length();
		maxStringLength = array[0].length();
		indexFirstMin = 0;
		indexLastMin = 0;
		indexFirstMax = 0;
		indexLastMax = 0;
		firstStringWithMinLength = array[array.length - 1];
		lastStringWithMinLength = array[0];
		firstStringWithMaxLength = array[array.length - 1];
		lastStringWithMaxLength = array[0];
	}

	public String toString()
	{
		return String.format(minStringLength + maxStringLength
				+ indexFirstMin + indexLastMin + indexFirstMax
				+ indexLastMax + firstStringWithMinLength
				+ lastStringWithMinLength
				+ firstStringWithMaxLength
				+ lastStringWithMaxLength);

	}
}
