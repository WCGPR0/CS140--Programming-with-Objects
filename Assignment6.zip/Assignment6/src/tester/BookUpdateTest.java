package tester;

import loops_and_arrays.ReadingTracker;
import java.io.FileNotFoundException;

public class BookUpdateTest
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		ReadingTracker myTracker = new ReadingTracker();
		myTracker.updateReadings();

	}

}
