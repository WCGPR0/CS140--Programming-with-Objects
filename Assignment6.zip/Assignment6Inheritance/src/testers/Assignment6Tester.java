package testers;

import utility.SingleRandom;
import game.*;

/**
 * Tester class for test game and Object I/O
 * 
 * @author Rose Williams
 * 
 */
public class Assignment6Tester
{

	/**
	 * Create instances of Human and Gruman Test their constructors and
	 * methods Have them interact with each other
	 * 
	 * @param args
	 */
	public static void main(String[] args)
	{
		String divider = "__________________________________________________";
		SingleRandom.getInstance().setSeed(1601);
		Game game = new Game();
		System.out.println(game);
		System.out.println(divider);

		for (int i = 0; i < game.getHumansSize(); i++)
		{
			game.defendGruman(i, i, game.attackGruman(i));
			game.defendHuman(i, i, game.attackHuman(i));
		}
		System.out.println(game);
	}
}