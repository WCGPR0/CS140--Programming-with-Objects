/**
 * A creature that resembles a human and has life, strength, and sacks of gold. It's objective is to avoid losing health and obtaining more than 10 sacks of gold. 
 * @author Victor Wu
 * Section 55- CS 140
 * Assignment 3
 */

package players;

import java.io.IOException;
import java.io.ObjectStreamClass;
//import java.util.logging.*;
import utility.SingleRandom;

public class Human extends Player // implements java.io.Serializable
{

	// Instance Class variables
	public final static int MIN_SACKS_TO_WIN;
	// private int myID = (int)serialVersionUID;
	/**
	 * This Human's debug logger
	 */
	/* private Logger log; */
	/**
	 * Configures logger output file
	 */
	/* private Handler handler; */
	// private final static long serialVersionUID;
	/**
	 * Static initialization
	 */
	static
	{
		// serialVersionUID =
		// ObjectStreamClass.lookup(Human.class).getSerialVersionUID();
		MIN_SACKS_TO_WIN = 10;
	}

	// Constructors
	/**
	 * Constructs an explicit constructor for a Human object
	 * 
	 * @param name
	 *                of Human
	 * @param sacks
	 *                of sacks for Human
	 * @param health
	 *                of max and initial health for Human
	 * @param strength
	 *                of Human
	 */
	public Human(String name, int sacks, double health, double strength)
	{
		super(name, sacks, strength);
		setHealth(Math.max(Math.min(health, MAX_HEALTH_POSSIBLE), 1));
		/*
		 * try { handler = new FileHandler("Human" + myID + ".txt");
		 * handler.setFormatter(new SimpleFormatter()); } catch
		 * (IOException e) { e.printStackTrace(); } log =
		 * Logger.getLogger("Human"+ myID); log.addHandler(handler);
		 * log.setLevel(Level.ALL);
		 * 
		 * //log.setLevel(Level.OFF);
		 */// TURNS LOGGER OFF
	}

	/**
	 * Constructs a partially explicit constructor for a Human object with 0
	 * sacks
	 * 
	 * @param name
	 *                of Human
	 * @param health
	 *                of max and initial health for Human
	 * @param strength
	 *                of Human
	 */
	public Human(String name, double health, double strength)
	{
		this(name, 0, health, strength);
	}

	/**
	 * Constructs a partially explicit constructor for a Human object with 0
	 * sacks, random health and strength
	 * 
	 * @param name
	 *                of Human
	 */
	public Human(String name)
	{
		this(name, 0, SingleRandom.getInstance().nextInt(
				(int) HEALTH_SCALE), SingleRandom.getInstance()
				.nextInt((int) STRENGTH_SCALE));
	}

	/**
	 * Constructs a Human named "Anonymous" and has 0 sacks and random
	 * health and strength
	 */
	public Human()
	{

		this("Anonymous");
	}

	// Accessors
	/**
	 * Gets the poke power of Human
	 * 
	 * @return the poke power from formula: strength / HEALTH_SCALE * health
	 */
	public double pokeGruman()
	{

		return getStrength() / HEALTH_SCALE * getHealth();
	}

	// Predicate methods
	/**
	 * Checks the condition to win
	 * 
	 * @return the boolean of (sacks > NUMBER_SACKS_TO_WIN)
	 */
	public boolean hasSacksToWin()
	{
		return (getSacks() >= MIN_SACKS_TO_WIN);
	}

	// Mutators
	/**
	 * Receives damage and loses health and strength
	 * 
	 * @param force
	 *                power of Gruman's terror
	 */
	public void sufferTerror(double force)
	{
		setHealth(Math.max(getHealth() - force, 0));
		setStrength(Math.max(getStrength() - (force / STRENGTH_SCALE),
				0));
	}
}
