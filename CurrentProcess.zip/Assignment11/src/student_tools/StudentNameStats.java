package student_tools;

import interfaces.GenericCustomStats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import application_objects.Person;
import application_objects.Student;

public class StudentNameStats implements GenericCustomStats<Student, String, String>
{
	private class StudentNameComparator implements Comparator<Student>
	{

		public int compare(Student o1, Student o2)
		{
		return (o1).getName().compareTo(o2.getName());
		}

	}
	private Comparator<Student> comparator;
	public StudentNameStats (Comparator<Student> comparator){
		this.comparator = comparator;
	}

	public String average(ArrayList<Student> persons)
	{
 return median(persons);
	}

	public String median(ArrayList<Student> persons)
	{
	  ArrayList tempArray = new ArrayList<String>();
	  for (int i = 0; i < persons.size(); i++)
	  {
	    tempArray.add(i, persons.get(i).getName());
	  }
	  Collections.sort(tempArray);
	  String median = "";
	  if (tempArray.size() % 2 == 0)
	  {
	    median = ((String)tempArray.get(tempArray.size() / 2)) +
	        (tempArray.get((tempArray.size() / 2) - 1));
	  }
	  else if (tempArray.size() % 2 != 0 && tempArray.size() > 0)
	  {
	    median = (String) tempArray.get((int) ((tempArray.size() / 2) - .5));
	  }
	  return median;
	}
	public String getFieldValue(ArrayList<Student> persons, int index){
		return persons.get(index).getName();
	}
	public String getFieldValue(Student persons){
		return persons.getName();
	}

	public Comparator getComparator()
	{
		return comparator;
	}
}
