package student_tools;

import interfaces.GenericCustomStats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import application_objects.Student;

public class StudentIDStats implements GenericCustomStats<Student, Double, String>
{
	private class StudentAgeComparator implements Comparator<Student>
	{

		public int compare(Student p1, Student p2)
		{
			return ((p1).getAge() > (p2).getAge()) ? 1 : ((p1).getAge() == (p2).getAge()) ? 0 : -1 ;	
		}
	}
	private Comparator<Student> comparator;
	public StudentIDStats (Comparator<Student> comparator){
		this.comparator = comparator;
	}

	public Double average(ArrayList<Student> persons)
	{
		double sum = 0;
		for (Student student : persons){
			sum+= Integer.parseInt(student.getID());
		}
		sum /= persons.size();
		return sum;
	}

	public Double median(ArrayList<Student> persons)
	{
	Double doubleMedian = new Double(-1601);
	  ArrayList tempArray = new ArrayList<String>();
	  for (int i = 0; i < persons.size(); i++)
	  {
	    tempArray.add(i, persons.get(i).getID());
	  }
	  Collections.sort(tempArray);
	  String median = "";
	  if (tempArray.size() % 2 == 0)
	  {
	    median = ((String)tempArray.get(tempArray.size() / 2)) +
	        (tempArray.get((tempArray.size() / 2) - 1));
	    doubleMedian = (double) Integer.parseInt(median);
	  }
	  else if (tempArray.size() % 2 != 0 && tempArray.size() > 0)
	  {
	    median = (String) tempArray.get((int) ((tempArray.size() / 2) - .5));
	    doubleMedian = (double) Integer.parseInt(median) / 2;
	  }
	  return doubleMedian;
	}
	public String getFieldValue(ArrayList<Student> persons, int index){
		return persons.get(index).getID();
	}
	public String getFieldValue(Student persons){
		return persons.getID();
	}

	public Comparator getComparator()
	{
		return comparator;
	}
}
