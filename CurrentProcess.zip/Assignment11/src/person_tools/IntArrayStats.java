/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */

package person_tools;

public class IntArrayStats
{
	/**
	 * The smallest value in the array
	 */
	private int minimum;
	/**
	 * The largest value in the array
	 */
	private int maximum;
	/**
	 * The smallest array index where the minimum occurs
	 */
	private int firstMinIndex;
	/**
	 * The largest array index where the minimum occurs
	 */
	private int lastMinIndex;
	/**
	 * The smallest array index where the maximum occurs
	 */
	private int firstMaxIndex;
	/**
	 * The largest array index where the maximum occurs
	 */
	private int lastMaxIndex;
	/**
	 * The average of all the values in the array
	 */
	private double average;
	/**
	 * The center value of the sorted array if array length is odd OR
	 * average of the 2 center values if the array length is even
	 */
	private double median;

	/**
	 * 
	 * @return min
	 */
	public int getMinimum()
	{
		return minimum;
	}

	/**
	 * 
	 * @return max
	 */
	public int getMaximum()
	{
		return maximum;
	}

	/**
	 * 
	 * @return first min index
	 */
	public int getIndexFirstMin()
	{
		return firstMinIndex;
	}

	/**
	 * 
	 * @return first max index
	 */
	public int getIndexFirstMax()
	{
		return firstMaxIndex;
	}

	/**
	 * 
	 * @return last max index
	 */
	public int getIndexLastMax()
	{
		return lastMaxIndex;
	}

	/**
	 * 
	 * @return last min index
	 */
	public int getIndexLastMin()
	{
		return lastMinIndex;
	}

	/**
	 * @return average
	 */
	public double getAverage()
	{
		return average;
	}

	/**
	 * 
	 * @return median
	 */
	public double getMedian()
	{
		return median;
	}

	public IntArrayStats(int minimum, int maximum, int firstMinIndex,
			int lastMinIndex, int firstMaxIndex, int lastMaxIndex,
			double average, double median)
	{
		this.minimum = minimum;
		this.maximum = maximum;
		this.firstMinIndex = firstMinIndex;
		this.lastMinIndex = lastMinIndex;
		this.firstMaxIndex = firstMaxIndex;
		this.average = average;
		this.median = median;
		this.toString();
	}
}
