/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */

package loops_and_arrays;

import java.util.Arrays;

public class IntArrayAnalyzer
{
	public IntArrayAnalyzer()
	{

	}

	/**
	 * Finds the minimum in the array or 0 if the array is null or empty
	 * 
	 * @param array
	 * @return minimum in the array or 0 if the array is null or empty
	 */
	private int min(int[] array)
	{
		int min = array[0];
		for (int i = 0; i < array.length - 1; i++)
		{
			min = Math.min(array[i], min);
		}
		return min;
	}

	/**
	 * Finds the maximum in the array or 0 if the array is empty
	 * 
	 * @param array
	 * @return maximum in array or 0 if array is null or empty
	 */
	private int max(int[] array)
	{
		int max = array[0];
		for (int i = 0; i < array.length - 1; i++)
		{
			max = Math.max(array[i], max);
		}
		return max;
	}

	/**
	 * Finds the smallest index where value occurs or returns -1 if the
	 * array is null or empty or value does not occur in the array.
	 * 
	 * @param value
	 * @param array
	 * @return the first value with the marked value
	 */
	private int firstValueIndex(int value, int[] array)
	{
		for (int i = 0; i < array.length - 1; i++)
		{
			if (array[i] == value)
			{
				return i;
			}
		}
		return -1;
	}

	/**
	 * Finds the largest index where value occurs or -1 if the array is null
	 * or empty or value does not occur in the array
	 * 
	 * @param value
	 * @param array
	 * @return the last value with the marked value
	 */
	private int lastValueIndex(int value, int[] array)
	{
		for (int i = array.length - 1; i > 0; i--)
		{
			if (array[i] == value)
			{
				return i;
			}
		}
		return -1;
	}

	/**
	 * Computes the average of all the values in the array or 0 if the array
	 * is null or empty
	 * 
	 * @param array
	 * @return the average in this array
	 */
	private double average(int[] array)
	{
		int average = 0;
		for (int i = 0; i < array.length - 1; i++)
		{
			average += array[i];
		}
		return average;
	}

	/**
	 * Copies, sorts the array and finds the center or the average
	 * 
	 * @param array
	 * @return the median in this array (or the average between the two
	 *         middle competing numbers)
	 */
	private double median(int[] array)
	{
		Arrays.sort(array);
		if (array.length % 2 == 0)
			return array[array.length / 2];
		else
			return array[(int) (array.length / 2) + 1]
					- array[(int) (array.length / 2)];

	}

	/**
	 * Uses all the private methods above to calculate the values needed to
	 * create an IntArrayStats object and then return it
	 * 
	 * @param array
	 * @return a calculated IntArrayStats object
	 */
	public IntArrayStats analyze1(int[] array)
	{
		return new IntArrayStats(min(array), max(array),
				firstValueIndex(min(array), array),
				lastValueIndex(min(array), array),
				firstValueIndex(max(array), array),
				lastValueIndex(max(array), array),
				average(array), median(array));
	}

	public IntArrayStats analyze2(int[] array)
	{
		// Minimum value
		int min = array[0];
		for (int i = 0; i < array.length - 1; i++)
		{
			min = Math.min(array[i], min);
		}
		// Maximum value
		int max = array[0];
		for (int i = 0; i < array.length - 1; i++)
		{
			max = Math.max(array[i], max);
		}
		// First value of index of minimum
		boolean found = false;
		int firstMinIndex = -1;
		for (int i = 0; i < array.length - 1 && !found; i++)
		{
			if (array[i] == min)
			{
				found = true;
				firstMinIndex = i;
			}
		}
		// Last value of index of minimum
		int lastMinIndex = -1;
		for (int i = array.length - 1; i > 0 && !found; i++)
		{
			if (array[i] == min)
			{
				found = true;
				firstMinIndex = i;
			}
		}
		// First value of index of maximum
		int firstMaxIndex = -1;
		for (int i = 0; i < array.length - 1 && !found; i++)
		{
			if (array[i] == max)
			{
				found = true;
				firstMinIndex = i;
			}
		}
		// Last value of index of minimum
		int lastMaxIndex = -1;
		for (int i = array.length - 1; i > 0 && !found; i++)
		{
			if (array[i] == max)
			{
				found = true;
				lastMaxIndex = i;
			}
		}
		// Average
		int average = 0;
		for (int i = 0; i < array.length - 1; i++)
		{
			average += array[i];
		}
		// Median
		int median;
		Arrays.sort(array);
		if (array.length % 2 == 0)
			median = array[array.length / 2];
		else
			median = array[(int) (array.length / 2) + 1]
					- array[(int) (array.length / 2)];
		return new IntArrayStats(min, max, firstMinIndex, lastMinIndex,
				firstMaxIndex, lastMaxIndex, average, median);

	}
}
