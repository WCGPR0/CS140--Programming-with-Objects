package interfaces;

import java.util.ArrayList;
import java.util.Comparator;
import application_objects.Person;

/**
 * This interface will be used in conjunction with a comparator
 * to compute average and median for a collection of objects
 * 
 * @author Rose Williams
 */
public interface GenericCustomStats <E, T, U>
{
  /**
   * Returns the associated comparator
   * @return comparator
   */
  Comparator<E> getComparator();
  
  /**
   * Compute and return the appropriate average
   * @param persons collection
   * @return appropriate average given chosen comparator field 
   */
  T average(ArrayList<E> aList);
  
  /**
   * Compute and return the appropriate median
   * @param persons collection
   * @return appropriate median given chosen comparator field 
   */
  T median(ArrayList<E> aList);
  
  /**
   * Returns the value of the field(s) used by the associated comparator
   * @param persons collection
   * @param index of collection
   * @return value of field(s) used by the comparator
   */ 
  U getFieldValue(ArrayList<E> aList, int index);
  
  /**
   * Returns the value of the field(s) used by the associated comparator
   * @param p - single person object
   * @return value of field(s) used by the comparator
   */   
  U getFieldValue(E e);    
}