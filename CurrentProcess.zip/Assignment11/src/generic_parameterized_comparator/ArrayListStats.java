package generic_parameterized_comparator;
import application_objects.Person;

public class ArrayListStats<E, T, U>
{

	/**
	 * Age of the youngest person(s) in the ArrayList
	 */
	private U minValue;
	/**
	 * Age of the oldest person(s) in the ArrayList
	 */
	Object maxValue;
	/**
	 * The name of the youngest person in the ArrayList that appears first
	 * in the array
	 */
	E firstYoungestName;
	/**
	 * The index in the ArrayList of the first youngest person
	 */
	int indexFirstMin;
	/**
	 * The name of the youngest person that appears last in theArrayList
	 */
	E lastYoungestName;
	/**
	 * The index in the ArrayList of the last youngest person
	 */
	int indexLastMin;
	/**
	 * The name of the oldest person that appears first in the ArrayList
	 */
	E firstOldestName;
	/**
	 * The index in the ArrayList of the first oldest person
	 */
	int indexFirstMax;
	/**
	 * The name of the oldest person that appears last in the ArrayList
	 */
	E lastOldestName;
	/**
	 * The index in the ArrayList of the last oldest person
	 */
	int indexLastMax;
	/**
	 * Average age of all the Persons
	 */
	private T average;
	/**
	 * Median age of all the Persons
	 */
	Object median;
	
	
/**
 * Explicit Constructor
 * @param minValue
 * @param maxValue
 * @param firstYoungestName
 * @param indexFirstMin
 * @param lastYoungestName
 * @param indexLastMin
 * @param firstOldestName
 * @param indexFirstMax
 * @param lastOldestName
 * @param indexLastMax
 * @param average
 * @param median
 */
	public ArrayListStats(U minValue, Object maxValue, E firstYoungestName,
			int indexFirstMin, E lastYoungestName,
			int indexLastMin, E firstOldestName, int indexFirstMax,
			E lastOldestName,int indexLastMax, T average,
			Object median)
	
	
	{
		this.minValue = minValue;
		this.maxValue = maxValue;
		this.firstYoungestName = firstYoungestName;
		this.indexFirstMin = indexFirstMin;
		this.lastYoungestName = lastYoungestName;
		this.indexLastMin = indexLastMin;
		this.firstOldestName = firstOldestName;
		this.indexFirstMax = indexFirstMax;
		this.lastOldestName = lastOldestName;
		this.indexLastMax = indexLastMax;
		this.average = average;
		this.median = median;
		this.toString();
	}
	
@Override
	public String toString ()
	{
		return String.format("Min Age: %s, MaxAge: %s, First Youngest Name: %s, " +
				"Index First Min: %d, Last Youngest Name: %s, Last Max Index: %d," +
				"Index Last Min: %d, First Oldest Name: %s, Index First Max: %d, Last Oldest Name: %s," +
				"Index Last Max: %d, Average Age: %.2d, Median Age: %.2d", minValue,maxValue,
				firstYoungestName,indexFirstMin,lastYoungestName,indexLastMin,firstOldestName,
				indexFirstMax,lastOldestName,indexLastMax,average,median);
	}

}
