package testers;

import game.*;

/**
 * Tester class for test game and Object I/O
 * 
 * @author Rose Williams
 * 
 */
public class Assignment4Tester
{  
  
  /**
   * Create instances of Human and Gruman 
   * Test their constructors and methods
   * Have them interact with each other
   * Save their state
   * Read it back and check
   * 
   * @param args
   */
  public static void main(String[] args)
  {
    String divider = "__________________________________________________";
    Game game = new Game();
    System.out.println(game);
    System.out.println(divider);

    for (int i = 0; i < game.getHumansSize(); i++)
    {
      game.defendGruman(i, i, game.attackGruman(i));
      game.defendHuman(i,  i,  game.attackHuman(i));
    }
    
    System.out.println(divider);
    System.out.println(game);
    System.out.println("Now save:");
    System.out.println(divider);
    
    Storage fileCabinet = new Storage();
    fileCabinet.setSaveFile();
    if (fileCabinet.hasFile())
    {
      fileCabinet.write(game);
    }

    game = null;
    System.out.println("Create a new game:");
    game = new Game();
    System.out.println(game);
    System.out.println(divider);

    System.out.println("Now load the original game:");
    game = null;
    fileCabinet.setOpenFile();
    if (fileCabinet.hasFile())
    {
      game = (Game) fileCabinet.read();
    }
    
    System.out.println(game);
    System.out.println(divider);
  }
}
