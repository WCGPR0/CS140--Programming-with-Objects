package testers;

import players.*;
import utility.SingleRandom;
import java.io.*;
import java.util.Arrays;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;


/**
 * Tester class for Human and Gruman
 * 
 * @author Rose Williams
 * 
 */
public class Lab4Tester
{  
  public final static Human [] HUMANS = 
    {
      new Human(),new Human("HNeg", -1, -1), new Human("HOver", 100.1, 10.1),
      new Human("HLowest", 0, 0), new Human("HLower", 1, 1),
      new Human("HHighest", 100, 10), new Human("HHigher", 99, 9),
      new Human("HMid", 50, 5) 
    };
  
  public final static Gruman [] GRUMANS = 
    {
      new Gruman(),
      new Gruman("GNeg", -1, -1, -1), new Gruman("GOver", 11, 100.1, 10.1),
      new Gruman("GLowest", 0, 0, 0), new Gruman("GLower", 1, 1, 1),
      new Gruman("GHighest", 10, 100, 10), new Gruman("GHigher", 9, 99, 9),
      new Gruman("GMid", 5, 50, 5) 
    };
  
  ArrayList<Human> humans;
  ArrayList<Gruman> grumans;
  
  public Lab4Tester()
  {
    humans = new ArrayList<Human>(Arrays.asList(HUMANS));
    grumans = new ArrayList<Gruman>(Arrays.asList(GRUMANS));
  }
  
  /**
   * Create instances of Human and Gruman 
   * Test their constructors and methods
   * Make sure that values are bound when appropriate
   * 
   * @param args
   */
  public static void main(String[] args)
  {
    Lab4Tester tester = new Lab4Tester();
    tester.test();
  }
  
  public void test()
  {
    final int DEFAULT = 0;
    final int NEGATIVE = 1;
    final int OVER = 2;
    final int LOWEST = 3;
    final int LOWER = 4;
    final int HIGHEST = 5;
    final int HIGHER = 6;
    final int MID = 7;

    File file;
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY); 
    
    int counter = -1;
    String divider = "__________________________________________________";
    
    counter++;//1
    System.out.println(counter);
    System.out.println("Default human:  \n" + humans.get(DEFAULT) +
      "\nDefault gruman:  \n" + grumans.get(DEFAULT) + "\n");
    
    counter++;//2
    System.out.println(counter);
    // Show that negative values are rejected, set to 1 instead
    System.out.println("Negative value human:  \n" + humans.get(NEGATIVE) +
      "\nNegative value gruman:  \n" + grumans.get(NEGATIVE) + "\n");
    
    counter++;//3
    System.out.println(counter);
    // Show that values over upper limit are rejected,
    // set to upper limit instead
    System.out.println("Over limit value human:  \n" + humans.get(OVER) +
      "\nOver limit value gruman:  \n" + grumans.get(OVER) + "\n");
    
    counter++;//4    
    System.out.println(counter);
    // Show that normal values are accepted, including those around "edges"
    // Should force health and strength values to 1                          
    System.out.println("Lowest value human:  \n" + humans.get(LOWEST) +
     "\nLowest value gruman:  \n" + grumans.get(LOWEST) + "\n");
    
    counter++;//5
    System.out.println(counter);
    // values are acceptable
    System.out.println("Lower value human:  \n" + humans.get(LOWER) +
      "\nLower value gruman:  \n" + grumans.get(LOWER) + "\n");
    
    counter++;//6
    System.out.println(counter);
    // values are highest allowable
    System.out.println("Highest value human:  \n" + humans.get(HIGHEST) +
      "\nHighest value gruman:  \n" + grumans.get(HIGHEST) + "\n");
    
    counter++;//7
    System.out.println(counter);
    // Values are acceptably high
    System.out.println("Higher value human:  \n" + humans.get(HIGHER) +
      "\nHigher value gruman:  \n" + grumans.get(HIGHER) + "\n");
    
    counter++;//8
    System.out.println(counter);
    // Values are midrange
    System.out.println("Mid value human:  \n" + humans.get(MID) +
      "\nMid value gruman:  \n" + grumans.get(MID) + "\n");
    
    counter++;//9
    System.out.println(counter);
    // Test accessors (that haven't been tested already)
    System.out.println("Mid value human accessors:  \nname = "
      + humans.get(MID).getName() + ", sacks = " + humans.get(MID).getSacks() + 
      ", health = " + humans.get(MID).getHealth() + 
      ", strength = " + humans.get(MID).getStrength()
      + ", poke force = " + humans.get(MID).pokeGruman()
      + "\nMid value gruman accessors:  \nname = " + grumans.get(MID).getName()
      + ", sacks = " + grumans.get(MID).getSacks() + 
      ", health = " + grumans.get(MID).getHealth()
      + ", strength = " + grumans.get(MID).getStrength() + ", roar force = "
      + grumans.get(MID).terrifyHuman() + "\n");
    
    counter++;//10
    System.out.println(counter);
    // Test predicate methods
    System.out.println("Lowest value human: \n"
      + ((humans.get(LOWEST).hasSacks()) ? "has" : "has no") + " sacks, "
      + (humans.get(LOWEST).hasHealth() ? "has" : "has no") + " health, "
      + (humans.get(LOWEST).hasStrength() ? "has" : "has no") 
      + " strength, and "
      + (humans.get(LOWEST).hasSacksToWin() ? "has" : "does not have")
      + " enough sacks to win" + "\nLowest value gruman: \n"
      + ((grumans.get(LOWEST).hasSacks()) ? "has" : "has no") + " sacks, "
      + (grumans.get(LOWEST).hasHealth() ? "has" : "has no") + " health, and "
      + (grumans.get(LOWEST).hasStrength() ? "has" : "has no") + " strength\n");
    
    counter++;//11
    System.out.println(counter);
    System.out.println("Highest value human: \n"
      + (humans.get(HIGHEST).hasSacks() ? "has" : "has no" + " sacks, ")
      + (humans.get(HIGHEST).hasHealth() ? "has" : "has no") + " health, "
      + (humans.get(HIGHEST).hasStrength() ? "has" : "has no") 
      + " strength, and "
      + (humans.get(HIGHEST).hasSacksToWin() ? "has" : "does not have")
      + " enough sacks to win" + "\nHighest value gruman : \n"
      + ((grumans.get(HIGHEST).hasSacks()) ? "has" : "has no") + " sacks, "
      + (grumans.get(HIGHEST).hasHealth() ? "has" : "has no") + " health, and "
      + 
      (grumans.get(HIGHEST).hasStrength() ? "has" : "has no") + " strength\n");
    
    counter++;//12
    System.out.println(counter);
    humans.get(HIGHEST).setSacks(Human.NUMBER_SACKS_TO_WIN);
    System.out.println("After setting sacks to NUMBER_SACKS_TO_WIN, "
      + "highest value human: \n"
      + (humans.get(HIGHEST).hasSacks() ? "has" : "has no") + " sacks, "
      + (humans.get(HIGHEST).hasHealth() ? "has" : "has no") + " health, "
      + (humans.get(HIGHEST).hasStrength() ? "has" : "has no") 
      + " strength, and "
      + (humans.get(HIGHEST).hasSacksToWin() ? "has" : "does not have")
      + " enough sacks to win\n");
    
    counter++;//13
    System.out.println(counter);
    System.out.println("Mid value human: \n"
      + ((humans.get(MID).hasSacks()) ? "has" : "has no") + " sacks, "
      + (humans.get(MID).hasHealth() ? "has" : "has no") + " health, "
      + (humans.get(MID).hasStrength() ? "has" : "has no") + " strength, and "
      + (humans.get(MID).hasSacksToWin() ? "has" : "does not have")
      + " enough sacks to win" + "\nMid value gruman : \n"
      + ((grumans.get(MID).hasSacks()) ? "has" : "has no") + " sacks, "
      + (grumans.get(MID).hasHealth() ? "has" : "has no") + " health, and "
      + (grumans.get(MID).hasStrength() ? "has" : "has no") + " strength\n");
    
    // Test mutators
    
    counter++;//14
    System.out.println(counter);
    humans.get(MID).incrementSacks();
    humans.get(MID).reduceStrength();
    System.out.println(
      "Mid value human after incrementing sacks and reducing strength:  \n" 
      + humans.get(MID));
    
    counter++;//15
    System.out.println(counter);
    humans.get(MID).sufferTerror(grumans.get(MID).terrifyHuman());
    System.out.println("Mid value human after suffering terror: \n" + 
      humans.get(MID));
    
    counter++;//16
    System.out.println(counter);
    humans.get(MID).decrementSacks();
    humans.get(MID).restoreHealth();
    humans.get(MID).restoreStrength();
    System.out.println("Mid value human after decrementing sacks "
      + "and restoring health and strength: \n" + humans.get(MID));
    
    counter++;//17
    System.out.println(counter);
    humans.get(MID).setSacks(11);
    humans.get(MID).setHealth(80);
    humans.get(MID).setStrength(8);
    System.out.println("Mid value human after setting sacks to 11, "
      + "health to 80, and strength to 8: \n" + humans.get(MID));
    
    counter++;//18
    System.out.println(counter);
    humans.get(MID).setSacks(-1);
    humans.get(MID).setHealth(-1);
    humans.get(MID).setStrength(-1);
    System.out.println("Mid value human after setting sacks to -1, "
      + "health to -1, and strength to -1: \n" + humans.get(MID));
    
    counter++;//19
    System.out.println(counter);
    humans.get(MID).setSacks(8);
    humans.get(MID).setHealth(40);
    humans.get(MID).setStrength(4);
    System.out.println("Mid value human after setting sacks to 8, "
      + "health to 40, and strength to 4:  \n" + humans.get(MID));
    
    counter++;//20
    System.out.println(counter);
    humans.get(MID).resetHealth();
    humans.get(MID).resetStrength();
    System.out.println(
      "Mid value human after resetting health and strength:  \n" 
      + humans.get(MID));
    
    counter++;//21
    System.out.println(counter);
    grumans.get(MID).incrementSacks();
    grumans.get(MID).reduceStrength();
    System.out.println(
      "Mid value gruman after incrementing sacks and reducing strength:  \n"
       + grumans.get(MID));
    
    counter++;//22
    System.out.println(counter);
    grumans.get(MID).sufferPoke(humans.get(MID).pokeGruman());
    System.out.println("Mid value gruman after suffering poke:  \n" + 
      grumans.get(MID));
    
    counter++;//23
    System.out.println(counter);
    grumans.get(MID).decrementSacks();
    grumans.get(MID).restoreHealth();
    grumans.get(MID).restoreStrength();
    System.out.println("Mid value gruman after decrementing sacks "
      + "and restoring health and strength:  \n" + grumans.get(MID));
    
    counter++;//24
    System.out.println(counter);
    grumans.get(MID).setSacks(11);
    grumans.get(MID).setHealth(80);
    grumans.get(MID).setStrength(8);
    System.out.println("Mid value gruman after setting sacks to 11, "
      + "health to 80, and strength to 8:  \n" + grumans.get(MID));
    
    counter++;//25
    System.out.println(counter);
    grumans.get(MID).setSacks(-1);
    grumans.get(MID).setHealth(-1);
    grumans.get(MID).setStrength(-1);
    System.out.println("Mid value gruman after setting sacks to -1, "
      + "health to -1, and strength to -1:  \n" + grumans.get(MID));
    
    counter++;//26
    System.out.println(counter);
    grumans.get(MID).setSacks(8);
    grumans.get(MID).setHealth(40);
    grumans.get(MID).setStrength(4);
    System.out.println("Mid value gruman after setting sacks to 8, "
      + "health to 40, and strength to 4:  \n" + grumans.get(MID));
    
    counter++;//27
    System.out.println(counter);
    grumans.get(MID).resetHealth();
    grumans.get(MID).resetStrength();
    System.out.println(
      "Mid value gruman after resetting health and strength:  \n" + 
      grumans.get(MID));
    
    counter++;//28
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 7; i++)
    {
      humans.get(MID).sufferTerror(Gruman.MAX_STRENGTH_POSSIBLE);
      System.out.println("Mid value human after suffering (max)terror:  \n"
        + humans.get(MID));
    }
    
    counter++;//29
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 12; i++)
    {
      humans.get(MID).restoreHealth();
      humans.get(MID).restoreStrength();
      System.out.println(
        "Mid value human after restoring health and strength: \n" + 
        humans.get(MID));
    }
    
    counter++;//30
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 12; i++)
    {
      humans.get(MID).reduceStrength();
      System.out.println("Mid value human after reducing strength:  \n"
        + humans.get(MID));
    }
 
    counter++;//31
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 7; i++)
    {
      grumans.get(MID).sufferPoke(Human.MAX_STRENGTH_POSSIBLE);
      System.out.println("Mid value gruman after suffering (max)terror:  \n"
        + grumans.get(MID));
    }
    
    counter++;//32
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 12; i++)
    {
      grumans.get(MID).restoreHealth();
      grumans.get(MID).restoreStrength();
      System.out.println(
        "Mid value gruman after restoring health and strength:  \n" + 
        grumans.get(MID));
    }
    
    counter++;//33
    System.out.println(divider);
    System.out.println(counter + " (LOOP OUTPUT)");
    for (int i = 0; i < 12; i++)
    {
      grumans.get(MID).reduceStrength();
      System.out.println("Mid value gruman after reducing strength:  \n"
        + grumans.get(MID));
    }

    // Save the following output    
    
    System.out.println(divider);    
    for (Human human : humans)
    {
      System.out.println(human);
    }
    
    for (Gruman gruman : grumans)
    {
      System.out.println(gruman);
    }
    System.out.println(divider);
    //  At this point, save the output indicated to a text file
    
    
    int option;
    file = null;
    fileChooser.setDialogTitle("Save");
    option = fileChooser.showSaveDialog(null);
    if(option == JFileChooser.APPROVE_OPTION)
    {
      file =  fileChooser.getSelectedFile();
      if(file == null)
        JOptionPane.showMessageDialog(null, "Unsuccessful:  empty filename");
    }
    
    ObjectOutputStream outObjectStream = null;
    try
    {
      outObjectStream = new ObjectOutputStream(new FileOutputStream(file));
      try
      {
        outObjectStream.writeObject(humans);
        outObjectStream.writeObject(grumans);
      }
      finally
      {
        outObjectStream.close();
      }
    }
    catch (IOException e)
    {
      e.printStackTrace();
      System.out.println(e.getCause());
      JOptionPane.showMessageDialog(null, "Save failed:  IOException");
    }
    
    file = null;
    fileChooser.setDialogTitle("Open");
    option = fileChooser.showOpenDialog(null);
    if(option == JFileChooser.APPROVE_OPTION)
    {
      file =  fileChooser.getSelectedFile();
      if(file == null)
        JOptionPane.showMessageDialog(null, "Unsuccessful:  empty filename"); 
    }
    
    // Completely wipe out both arrayLists
    humans = null;
    grumans = null;    

    ObjectInputStream inObjectStream = null;
    try 
    {
      inObjectStream = new ObjectInputStream(new FileInputStream(file));  
      humans = (ArrayList<Human>) inObjectStream.readObject();
      grumans = (ArrayList<Gruman>) inObjectStream.readObject();
      try
      {        
      }
      finally
      {
        if (inObjectStream != null)
          inObjectStream.close();     
      }      
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
      System.out.println(e.getCause());
      JOptionPane.showMessageDialog(null, "Read failed:  not a valid file");
    } 
    catch (IOException e)
    {
        e.printStackTrace();
        System.out.println(e.getCause());
        JOptionPane.showMessageDialog(null, "Open failed:  IOException");
    }

    System.out.println(divider);    
    for (Human human : humans)
    {
      System.out.println(human);
    }

    for (Gruman gruman : grumans)
    {
      System.out.println(gruman);
    }    
    System.out.println(divider);
  }
}
