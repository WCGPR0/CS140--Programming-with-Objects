package person_tools;

import java.util.Comparator;

import application_objects.Person;

public class PersonAgeComparator implements Comparator<Person>
{

	public int compare(Person p1, Person p2)
	{
		return ((p1).getAge() > (p2).getAge()) ? 1 : ((p1).getAge() == (p2).getAge()) ? 0 : -1 ;	
	}
}
