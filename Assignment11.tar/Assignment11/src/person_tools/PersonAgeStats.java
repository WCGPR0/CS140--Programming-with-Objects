package person_tools;


import interfaces.GenericCustomStats;
import application_objects.Person;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PersonAgeStats implements GenericCustomStats<Person, Double, Integer>
{
private Comparator<Person> comparator;

public PersonAgeStats(Comparator<Person> comparator){
	this.comparator = comparator;
}

public Comparator getComparator (){
	return comparator;
}
public Double average(ArrayList<Person> persons)
{
return median(persons);
}

public Double median(ArrayList<Person> persons)
{
  ArrayList tempArray = new ArrayList<Double>();
  for (int i = 0; i < persons.size(); i++)
  {
    tempArray.add(i, (double) persons.get(i).getAge());
  }
  Collections.sort(tempArray);
  double median = 0;
  if (tempArray.size() % 2 == 0)
  {
    median = ((double) tempArray.get(tempArray.size() / 2)
        + (double) tempArray.get(tempArray.size() / 2) - 1) / 2;
  }
  else if (tempArray.size() % 2 != 0 && tempArray.size() > 0)
  {
    median = (double) tempArray.get((int) ((tempArray.size() / 2) - .5));
  }
  return (Double) median;
}
public Integer getFieldValue(ArrayList<Person> persons, int index){
	return (Integer) persons.get(index).getAge();
}
public Integer getFieldValue(Person persons){
	return (Integer)persons.getAge();
}
	
}
