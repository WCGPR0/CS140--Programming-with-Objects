package person_tools;

import interfaces.GenericCustomStats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import application_objects.Person;

public class PersonNameStats implements GenericCustomStats<Person, String, String>
{
	private Comparator<Person> comparator;
	public PersonNameStats (Comparator<Person> comparator){
		this.comparator = comparator;
	}

	public String average(ArrayList<Person> persons)
	{
 return median(persons);
	}

	public String median(ArrayList<Person> persons)
	{
	  ArrayList tempArray = new ArrayList<String>();
	  for (int i = 0; i < persons.size(); i++)
	  {
	    tempArray.add(i, persons.get(i).getName());
	  }
	  Collections.sort(tempArray);
	  String median = "";
	  if (tempArray.size() % 2 == 0)
	  {
	    median = ((String)tempArray.get(tempArray.size() / 2)) +
	        (tempArray.get((tempArray.size() / 2) - 1));
	  }
	  else if (tempArray.size() % 2 != 0 && tempArray.size() > 0)
	  {
	    median = (String) tempArray.get((int) ((tempArray.size() / 2) - .5));
	  }
	  return median;
	}
	public String getFieldValue(ArrayList<Person> persons, int index){
		return persons.get(index).getName();
	}
	public String getFieldValue(Person persons){
		return persons.getName();
	}

	@Override
	public Comparator getComparator()
	{
		return comparator;
	}
}
