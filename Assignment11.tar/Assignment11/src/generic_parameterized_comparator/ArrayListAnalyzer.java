package generic_parameterized_comparator;

import interfaces.GenericCustomStats;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import application_objects.Person;


public class ArrayListAnalyzer <E>
{
	  ArrayList<E> person; // instance variable
	   
	public ArrayListAnalyzer(ArrayList<E> collection)
	{
		//this.person = list;
	}
	
	public ArrayListStats analyze(ArrayList<E> collection)
	{
		 ArrayList<Integer> ages = new ArrayList<Integer>();
		 if (collection.size()==0) ages = null;
		 else for (E age : collection)
		 {
			
			 ages.add(age.getAge());
		 }
		/*IntListAnalyzer intListAnalyzer = new IntListAnalyzer();
		IntArrayStats agesStats = intListAnalyzer.analyze1(ages);*/
//Instance Variables
		    int minAge = agesStats.getMinimum();
		    int maxAge = agesStats.getMaximum();
		    double medianAge = agesStats.getMedian();
		    double averageAge = agesStats.getAverage();
		    int firstIndexMax = agesStats.getIndexFirstMax();
		    int firstIndexMin = agesStats.getIndexFirstMin();
		    int lastIndexMax = agesStats.getIndexLastMax();
		    int lastIndexMin = agesStats.getIndexLastMin();

		E firstYoungestName = null, 
				lastYoungestName = null, 
				firstOldestName = null, 
				lastOldestName = null;
		
		if (firstIndexMin >= 0) {
			firstYoungestName = collection.get(firstIndexMin);
		}
		else if (collection == null || collection.isEmpty())
		{
		firstIndexMax = -1; firstIndexMin = -1; lastIndexMax = -1; lastIndexMin = -1;
		}
		
		    return new ArrayListStats(minAge, maxAge, firstYoungestName,
				        firstIndexMin, lastYoungestName, lastIndexMin, firstOldestName,
				        firstIndexMax, lastOldestName, lastIndexMax, averageAge, medianAge);

	} 
	

	  
	/**
	 * 
	 * @return Person most minimum object or if all equal, the first Person
	 */
	public Emin(ArrayList<E> collection, Comparator<E> comparator)
	{
		assert(person.size() > 0);
		int i = 0;
		E minPerson = person.get(0);
		for (E tempPerson : person)
		{
			if (comparator.compare(minPerson,tempPerson) < 0)
			{
				minPerson = person.get(i);
			}
			i++;
		}
		return minPerson;
	}

	/**
	 * 
	 * @return Person most maximum object or if all equal, the first Person
	 */
	public E max(ArrayList<E> collection, Comparator<E> comparator)
	{
		assert(person.size() > 0);
		int i = 0;
		E maxPerson = person.get(0);
		for (E tempPerson : person)
		{
			if (comparator.compare(maxPerson,tempPerson) > 0)
			{
				maxPerson = person.get(i);
			}
			i++;
		}
		return maxPerson;
	}

	/**
	   * @return Int first person index
	   */
	  public int firstPersonIndex(ArrayList<E> collection, int element, Comparator<E> comparator)
	  {
assert(person.size() > 0);
int index = -1;
		for (int i = person.size()-1;  i > 0; i--)
		{
			if (comparator.compare(person.get(element),person.get(i)) == 0)
			{
				index = i;
			}
			
		}
		
	    return index;
	  }
	  
	  /**
	   * @return Int last person index
	   */
	  public int lastPersonIndex(ArrayList<E> collection, int element, Comparator<E> comparator)
	  {
		  assert(person.size() > 0);		 
	    int index = -1;
	    int i = 0;
	    for (E tempPerson : person)
	    {
	      if (comparator.compare(tempPerson, person.get(element)) == 0)
	      {
	        index = i;
	      }
	      i++;
	    }
	    return index;
	  }
	  
	  
	/**
	 * @return Average of the person' age
	 */
	public double average(ArrayList<E> collection)
	{
		assert(person.size() > 0);
		double average = 0;
		for (E tempPerson : person)
		{
			average += tempPerson.getAge();
		}
		average = average / (double) person.size();
		return average;
	}

	/**
	 * @return Median of the person' age
	 */
	public double median(ArrayList<E> collection)
	{
		assert(person.size() > 0);
		double median = 1601; // If median results in 1601, something
					// went wrong...
		// If size of person is even
		if (person.size() % 2 == 0)
		{
			median = person.get((person.size() / 2)).getAge();
		} else if (person.size() % 2 != 0)
		{
			median = (person.get(((person.size() / 2))).getAge() + person
					.get(((person.size() / 2) + 1))
					.getAge()) / 2;
		}
		return median;
	}
	  
	  /**
	   * Used to analyze the person list
	   * @return PersonArrayListStats object
	   */
	  public <T, U> ArrayListStats <E, T,U> analyze(ArrayList<E> collection, GenericCustomStats<E, T,U> cStats)
	  {

	    ArrayListStats<T, U> newObject = null;
	    if (person != null)
	    {
	      newObject = new ArrayListStats<E,T,U>(cStats.getFieldValue(min(cStats.getComparator())), 
		cStats.getFieldValue(max(cStats.getComparator())),
	        person.get(firstPersonIndex(person.indexOf(min(cStats.getComparator())),cStats.getComparator())),
	          firstPersonIndex(person.indexOf(min(cStats.getComparator())),cStats.getComparator()),
	          person.get(lastPersonIndex(person.indexOf(min(cStats.getComparator())),cStats.getComparator())),
	          lastPersonIndex(person.indexOf(min(cStats.getComparator())),cStats.getComparator()),
	          person.get(firstPersonIndex(person.indexOf(max(cStats.getComparator())),cStats.getComparator())),
	          firstPersonIndex(person.indexOf(max(cStats.getComparator())),cStats.getComparator()),
	          person.get(lastPersonIndex(person.indexOf(max(cStats.getComparator())),cStats.getComparator())),
	          lastPersonIndex(person.indexOf(max(cStats.getComparator())),cStats.getComparator()), 
	          cStats.average(person), 
	          cStats.median(person));
	    }
	    
	    return newObject;
	  }
}




