/**
 * This class helps bound the maximum and minimum values.
 * @author Victor Wu
 * Section 55- CS 140
 */

package utility;

public class MathHelper
{

  public MathHelper() {
    
  }
/**
 * Sets the boundaries and returns the max, min, or the value itself depending on the value input
 * @param min the low range of the boundary
 * @param max the high range of the boundary
 * @param unbounded the unbounded value to be checked within the boundary
 * @return the max, if unbounded is larger than that, the min, if the unbounded is lower than that else the unbounded itself.
 */
  public double setBounds(int min, int max, double unbounded) {
return Math.max(Math.min(max, unbounded),min);
}
}


