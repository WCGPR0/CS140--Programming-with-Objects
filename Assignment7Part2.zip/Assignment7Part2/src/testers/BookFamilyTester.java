package testers;

import java.util.ArrayList;

import books.*;

/**
 * Models a course associated with a text book
 * 
 * @author Victor Wu Section 55 - CS140
 */

public class BookFamilyTester
{

	public static void main(String[] args)
	{
		ElectronicBook myEBook = new ElectronicBook();
		ElectronicBook myEBook2 = new ElectronicBook(
				"The Oxford English Dictionary", 22000, 0,
				"pdf");
		TextBook myTextBook = new TextBook();
		TextBook myTextBook2 = new TextBook("Lined Notebook", 250, 0,
				true, new Course());
		System.out.println(myEBook.toString());
		System.out.println(myEBook2.toString());
		System.out.println(myTextBook.toString());
		System.out.println(myTextBook2.toString());
		System.out.println(myEBook.getTitle() + myEBook2.getTitle()
				+ myTextBook.getTitle()
				+ myTextBook2.getTitle());
		System.out.println(myEBook.getFormat() + myEBook2.getFormat());
		Book EBookRef1 = (ElectronicBook) myEBook;
		Book EBookRef2 = (ElectronicBook) myEBook;
		Book EBookRef3 = (ElectronicBook) myEBook;
		Book EBookRef4 = (ElectronicBook) myEBook;
		Book EBookRef5 = (ElectronicBook) myEBook;
		Book EBookRef6 = (ElectronicBook) myEBook;
		ArrayList<Book> myArrays = new ArrayList<Book>();
		myArrays.add(EBookRef1);
		myArrays.add(EBookRef2);
		myArrays.add(EBookRef3);
		myArrays.add(EBookRef4);
		myArrays.add(EBookRef5);
		myArrays.add(EBookRef6);
		for (Book i : myArrays)
		{
			System.out.println(i.toString());
			i.clone();
		}
		for (int i = 0; i < myArrays.size(); i++)
		{
			System.out.println(myArrays.get(i).toString());
			System.out.println(myArrays.get(i).equals(myEBook));
		}

	}
}
