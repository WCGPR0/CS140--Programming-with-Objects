package books;

/**
 * Models a textbook that associates a course and a book
 * 
 * @author Victor Wu Section 55 - CS140
 */

public class TextBook extends Book
{
	// Instance Variables
	/**
	 * Boolean of whether this textbook is required for class
	 */
	boolean required;
	/**
	 * Reference variable of type Course
	 */
	Course course = new Course();

	/**
	 * Default constructor that sets as default: title as "Lined Notebook"
	 * Page Count as 250 Bookmark as 0 this book to be Required for Course
	 * Course to be default
	 */
	public TextBook()
	{
		this("Lined Notebook", 250, 0, true, new Course());
	}

	/**
	 * Partially explicit constructor that sets as default: Bookmark as 0
	 * this book to be Required for Course
	 * 
	 * @param title
	 *                of the Book
	 * @param pageCount
	 *                of the Book
	 * @param course
	 *                type for the Book
	 */
	public TextBook(String title, int pageCount, Course course)
	{
		this(title, pageCount, 0, true, course);
	}

	/**
	 * Explicit constructor that sets as default:
	 * 
	 * @param title
	 *                of the Book
	 * @param pageCount
	 *                of the Book
	 * @param bookmark
	 *                of where to start in the Book
	 * @param required
	 *                for the class of this Book
	 * @param course
	 *                type for the Book
	 */
	public TextBook(String title, int pageCount, int bookmark,
			boolean required, Course course)
	{
		super(title, pageCount, bookmark);
		this.required = required;
		this.course = course;
	}

	/**
	 * "Generates independent copy of this Textbook that protected access
	 * from the Object class is overridden with public In order to override
	 * this method, this class must implement Cloneable, and provide
	 * exception handling for the CloneNotSupportedException"
	 * 
	 * @return Object: must cast to eBook when using
	 */
	@Override
	public Object clone()
	{
		TextBook cloned = null;

		cloned = (TextBook) super.clone();
		cloned.course = (Course) course.clone();
		return cloned;
	}

	/**
	 * Determines if this TextBook is equal to other TextBook
	 * 
	 * @return true when equal, false when not equal
	 */
	@Override
	public boolean equals(Object otherObject)
	{
		boolean isEqual = false;

		if (super.equals(otherObject)
				&& otherObject != null
				&& this.getClass().equals(
						otherObject.getClass()))
		{
			TextBook other = (TextBook) otherObject; // NOTE
			// CAST
			isEqual = course.equals(other.getCourse());
		}
		return isEqual;
	}

	/**
	 * "generate a unique code based on the contents of the object that, as much as possible, doesn't match any other hash codes (i.e., doesn't cause a collision)"
	 * 
	 * @return hash code for this TextBook
	 */
	@Override
	public int hashCode()
	{
		final int HASH_MULTIPLIER = 73; // use a prime number
		int result = (super.hashCode()) * HASH_MULTIPLIER;
		int result2 = course.hashCode() * HASH_MULTIPLIER;
		int requiredHashCode = new Boolean(required).hashCode();

		return result + result2 + requiredHashCode;
	}

	/**
	 * Returns formatted String representation of this eBook
	 * 
	 * @return formatted String representation of the current state of this
	 *         eBook
	 */
	@Override
	public String toString()
	{
		return String.format("%s %b %s", super.toString(), required,
				course.toString());
	}

	/**
	 * Checks if this book is required for the Course
	 * 
	 * @return true if the book is required, false if not required
	 */
	public boolean isRequired()
	{
		return required;
	}

	public Course getCourse()
	{
		return (Course) course.clone();
	}

	public static void main(String[] args)
	{
		TextBook myTextBook = new TextBook();
		System.out.println(myTextBook.hashCode());
		System.out.println(myTextBook.toString());
		myTextBook.course.equals(myTextBook.getCourse());
		myTextBook.course.equals(myTextBook.course.clone());
	}

}
