/** 
 * A subclass of the Book, and meant to be an electronic, online book
 * @author Victor Wu
 * Section 55 - CS140
 */

package books;

public class ElectronicBook extends Book
{
	// Instance variables
	/**
	 * Format of the electronic book
	 */
	private String format;
	/**
	 * Title of the electronic book
	 */
	private String title;
	/**
	 * Amount of pages in the electronic book
	 */
	int pageCount;
	/**
	 * The initial spot for the bookmark to start
	 */
	int bookmark;

	// Static variables declaration
	/**
	 * A static instance of this ElectronicBook class
	 */
	private static ElectronicBook instance;

	// Static variables initialization
	static
	{
		instance = new ElectronicBook();
	}

	/**
	 * Default constructor that sets the title as
	 * "The Oxford English Dictionary" the total number of pages as 22000
	 * the bookmark starting 0 the format as "pdf"
	 */
	public ElectronicBook()
	{
		this("The Oxford English Dictionary", 22000, 0, "pdf");
	}

	/**
	 * Partially explicit constructor which sets the format of the eBook
	 * 
	 * @param format
	 *                the type of format the eBook will be
	 */
	public ElectronicBook(String format)
	{
		this("The Oxford English Dictionary", 22000, 0, format);
	}

	/**
	 * Explicit constructor that sets title, pages, bookmark, and the format
	 * 
	 * @param title
	 *                of the book to be set as
	 * @param pages
	 *                the amount of pages to be set as
	 * @param bookmark
	 *                where the spot the bookmark start at
	 * @param format
	 *                the type of format the eBook will be
	 */
	public ElectronicBook(String title, int pageCount, int bookmark,
			String format)
	{
		this.title = title;
		this.pageCount = pageCount;
		this.bookmark = bookmark;
		this.format = format;
	}

	/**
	 * Gets the type of format of the eBook
	 * 
	 * @return format of the eBook
	 */
	public String getFormat()
	{
		return format;
	}

	/**
	 * "Generates independent copy of this book Note that protected access
	 * from the Object class is overridden with public In order to override
	 * this method, this class must implement Cloneable, and provide
	 * exception handling for the CloneNotSupportedException"
	 * 
	 * @return Object: must cast to eBook when using
	 */
	@Override
	public Object clone()
	{
		ElectronicBook cloned = null;

		cloned = (ElectronicBook) super.clone();
		return cloned;
	}

	/**
	 * Determines if this eBook is equal to other eBooks
	 * 
	 * @return true when equal, false when not equal
	 */
	@Override
	public boolean equals(Object otherObject)
	{
		boolean isEqual = false;

		if (super.equals(otherObject)
				&& otherObject != null
				&& this.getClass().equals(
						otherObject.getClass()))
		{
			ElectronicBook other = (ElectronicBook) otherObject; // NOTE
			// CAST
			isEqual = format.equals(other.getFormat());
		}
		return isEqual;
	}

	/**
	 * "generate a unique code based on the contents of the object that, as much as possible, doesn't match any other hash codes (i.e., doesn't cause a collision)"
	 * 
	 * @return hash code for this eBook
	 */
	@Override
	public int hashCode()
	{
		final int HASH_MULTIPLIER = 73; // use a prime number
		int result = (super.hashCode()) * HASH_MULTIPLIER;
		int titleHashCode = 0;
		for (int i = 0; i < title.length(); i++)
		{
			titleHashCode = titleHashCode + title.charAt(i);
		}

		int pageCountHashCode = new Integer(pageCount).hashCode();
		int bookmarkHashCode = new Integer(bookmark).hashCode();

		return result * titleHashCode + result * pageCountHashCode
				+ result * bookmarkHashCode;
	}

	/**
	 * Returns formatted String representation of this eBook
	 * 
	 * @return formatted String representation of the current state of this
	 *         eBook
	 */
	@Override
	public String toString()
	{
		return String.format("%s" + " format type: %s",
				super.toString(), format);
	}

	public static void main(String[] args)
	{
		ElectronicBook myEBook = new ElectronicBook();
		System.out.println(myEBook.hashCode());
		System.out.println(myEBook.toString());
	}

}
