package books;

/**
 * Models a course associated with a text book
 * @author Victor Wu 
 * Section 55 - CS140
 */

public class Course implements Cloneable
{
	// Instance Variables
	/**
	 * The serial code for the course
	 */
	protected String courseCode;
	/**
	 * The name for the course
	 */
	protected String courseName;

	/**
	 * Types of levels for the course
	 */
	public enum Level
	{
		UNDERGRADUATE, GRADUATE
	};

	protected Level level;

	/**
	 * Default constructor with values set as: courseCode as "CS100"
	 * courseName as "Introduction to Computer Science" Level as
	 * "UNDERGRADUATE"
	 */
	public Course()
	{
		this("CS100", "Introduction to Computer Science",
				Level.UNDERGRADUATE);
	}

	/**
	 * Partially explicit constructor
	 */
	public Course(String courseCode, String courseName)
	{
		this(courseCode, courseName, Level.UNDERGRADUATE);
	}

	/**
	 * Explicit constructor
	 * 
	 * @param courseCode
	 *                code of the course
	 * @param courseName
	 *                name of the course
	 * @param level
	 *                type of level of the course
	 */
	public Course(String courseCode, String courseName, Level level)
	{
		this.courseCode = courseCode;
		this.courseCode = courseName;
		this.level = level;
	}

	/**
	 * "Generates independent copy of this bookCourse that protected access
	 * from the Object class is overridden with public In order to override
	 * this method, this class must implement Cloneable, and provide
	 * exception handling for the CloneNotSupportedException"
	 * 
	 * @return Object: must cast to eBook when using
	 */
	@Override
	public Object clone()
	{
		Course cloned = null;
		try
		// Exception handling
		{
			// Pretty simple since everything is either primitive or
			// immutable
			cloned = (Course) super.clone();
		} catch (CloneNotSupportedException e) // Exception handling
		{
			// shouldn't happen because we implemented Cloneable
			e.printStackTrace();
		}
		return cloned;
	}

	/**
	 * Determines if this course is equal to other course
	 * 
	 * @return true when equal, false when not equal
	 */
	@Override
	public boolean equals(Object otherObject)
	{
		boolean isEqual = false;

		if (otherObject != null
				&& this.getClass().equals(
						otherObject.getClass()))
		{
			Course other = (Course) otherObject; // NOTE CAST
			isEqual = courseCode.equals(other.courseCode)
					&& courseName.equals(other.courseName)
					&& level.equals(other.level);
		}
		return isEqual;
	}

	/**
	 * Returns formatted String representation of this Course
	 * 
	 * @return formatted String representation of the current state of this
	 *         Course
	 */
	@Override
	public String toString()
	{
		return String.format("Course Code:  %s, " + "Course Name "
				+ "Level of Course ", courseCode, courseName,
				level);
	}

	public static void main(String[] args)
	{
		Course defaultCourse = new Course();
		Course explicitCourse = new Course("Insomnia101",
				"Living Without Sleep");
		System.out.println(explicitCourse.equals(defaultCourse.clone()));
		System.out.println(defaultCourse.toString());
		System.out.println(explicitCourse.toString());
	}

}
