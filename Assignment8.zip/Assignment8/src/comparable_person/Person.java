/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */
package comparable_person;

public class Person implements Comparable, Cloneable
{
	private String firstName;
	private String lastName;

	public enum gender
	{
		MALE, FEMALE;
	}

	public static gender gender;
	private int age;

	public Person(String firstName, String lastName, gender gender, int age)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}

	/**
	 * @return the full name
	 */
	public String getName()
	{
		return getLastName() + ", " + getFirstName();
	}

	/**
	 * @param firstName
	 *                the firstName to set
	 */
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName()
	{
		return lastName;
	}

	/**
	 * @param lastName
	 *                the lastName to set
	 */
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	/**
	 * @return the gender
	 */
	public gender getGender()
	{
		return gender;
	}

	/**
	 * @param gender
	 *                the gender to set
	 */
	public void setGender(gender gender)
	{
		this.gender = gender;
	}

	/**
	 * @return the age
	 */
	public int getAge()
	{
		return age;
	}

	/**
	 * @param age
	 *                the age to set
	 */
	public void setAge(int age)
	{
		this.age = age;
	}

	/**
	 * Increments age by one
	 */
	public void addAge()
	{
		age++;
		;
	}

	/**
	 * Generates this person's hash code with name and age
	 * 
	 * @return hash code for this person
	 */
	public int hashCode()
	{
		final int HASH_MULTIPLIER = 1601; // use a prime number
		int personHashCode = 0;
		for (int i = 0; i < getName().length(); i++)
		{
			personHashCode = personHashCode + getName().charAt(i);
		}

		int personAgeHashCode = new Integer(getAge()).hashCode();
		int personNameHashCode = new Integer(getName()).hashCode();

		return HASH_MULTIPLIER * personHashCode + HASH_MULTIPLIER
				* personAgeHashCode + HASH_MULTIPLIER
				* personNameHashCode;
	}

	/**
	 * Generates independent copy of this person Note that protected access
	 * from the Object class is overridden with public In order to override
	 * this method, this class must implement Cloneable, and provide
	 * exception handling for the CloneNotSupportedException
	 * 
	 * @return Object: must cast to Person when using
	 */
	public Object clone()
	{
		Person cloned = null;
		try
		{
			cloned = (Person) super.clone();
		} catch (CloneNotSupportedException e)
		{
			e.printStackTrace();
		}
		return cloned;
	}

	/**
	 * @param otherPerson
	 * @return an integer of -1 if age < compared otherPerson; 1 if age >
	 *         compared otherPerson; or 0 if it equals
	 */
	public int compareTo(Object otherPerson)
	{
		int compared;
		if (this.age < ((Person) otherPerson).getAge())
		{
			compared = -1;
		} else if (this.age == ((Person) otherPerson).getAge())
		{
			compared = 0;
		} else if (this.age > ((Person) otherPerson).getAge())
		{
			compared = 1;
		} else
		{
			compared = -1601;
			throw new IllegalArgumentException(
					"Something went wrong with comparing the two Person objects!");
		} // ERROR (Should never been reached)
		return compared;
	}

	/**
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return "Person [firstName=" + firstName + ", lastName="
				+ lastName + ", gender=" + gender + ", age="
				+ age + "]";
	}
}