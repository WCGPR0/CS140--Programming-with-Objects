/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */
package comparable_person;

import java.util.ArrayList;

public class PersonArrayListAnalyzer
{

	ArrayList<Person> persons; // instance variable

	public PersonArrayListAnalyzer(ArrayList<Person> list)
	{
		this.persons = list;
	}

	public PersonArrayListStats analyze(ArrayList<Person> list)
	{
		ArrayList<Integer> ages = new ArrayList<Integer>();
		if (list.size() == 0)
			ages = null;
		else
			for (Person age : list)
			{
				ages.add(age.getAge());
			}
		IntListAnalyzer intListAnalyzer = new IntListAnalyzer();
		IntArrayStats agesStats = intListAnalyzer.analyze1(ages);
		// Instance Variables
		int minAge = agesStats.getMinimum();
		int maxAge = agesStats.getMaximum();
		double medianAge = agesStats.getMedian();
		double averageAge = agesStats.getAverage();
		int firstIndexMax = agesStats.getIndexFirstMax();
		int firstIndexMin = agesStats.getIndexFirstMin();
		int lastIndexMax = agesStats.getIndexLastMax();
		int lastIndexMin = agesStats.getIndexLastMin();

		Person firstYoungestName = null, lastYoungestName = null, firstOldestName = null, lastOldestName = null;

		if (firstIndexMin >= 0)
		{
			firstYoungestName = list.get(firstIndexMin);
		} else if (list == null || list.isEmpty())
		{
			firstIndexMax = -1;
			firstIndexMin = -1;
			lastIndexMax = -1;
			lastIndexMin = -1;
		}

		return new PersonArrayListStats(minAge, maxAge,
				firstYoungestName, firstIndexMin,
				lastYoungestName, lastIndexMin,
				firstOldestName, firstIndexMax, lastOldestName,
				lastIndexMax, averageAge, medianAge);

	}

	/**
	 * 
	 * @return Person most minimum object or if all equal, the first Person
	 */
	public Person min()
	{
		int i = 0;
		Person minPerson = persons.get(0);
		for (Person tempPersons : persons)
		{
			if (tempPersons.compareTo(persons.get(i)) == 1)
			{
				tempPersons = persons.get(i);
			}
			minPerson = tempPersons;
			i++;
		}
		return minPerson;
	}

	/**
	 * 
	 * @return Person most maximum object or if all equal, the first Person
	 */
	public Person max()
	{
		int i = 0;
		Person maxPerson = persons.get(0);
		for (Person tempPersons : persons)
		{
			if (tempPersons.compareTo(persons.get(i)) == -1)
			{
				tempPersons = persons.get(i);
			}
			maxPerson = tempPersons;
			i++;
		}
		return maxPerson;
	}

	/**
	 * @return Average of the persons' age
	 */
	public double average()
	{
		double average = 0;
		for (Person tempPersons : persons)
		{
			average += tempPersons.getAge();
		}
		average = average / (double) persons.size();
		return average;
	}

	/**
	 * @return Median of the persons' age
	 */
	public double median()
	{
		double median = 1601; // If median results in 1601, something
					// went wrong...
		// If size of persons is even
		if (persons.size() % 2 == 0)
		{
			median = persons.get((persons.size() / 2)).getAge();
		} else if (persons.size() % 2 != 0)
		{
			median = (persons.get(((persons.size() / 2))).getAge() + persons
					.get(((persons.size() / 2) + 1))
					.getAge()) / 2;
		}
		return median;
	}

	public PersonArrayListStats analyze()
	{
		PersonArrayListStats newObject = null;
		if (persons != null)
		{
			ArrayList<Integer> ages = new ArrayList<Integer>();
			if (persons.size() == 0)
				ages = null;
			else
				for (Person age : persons)
				{
					ages.add(age.getAge());
				}
			IntListAnalyzer intListAnalyzer = new IntListAnalyzer();
			IntArrayStats agesStats = intListAnalyzer
					.analyze1(ages);

			// NOT WORKING - WILL BE FIXED THOUGH
			newObject = new PersonArrayListStats(min().getAge(),
					max().getAge(), min(),
					agesStats.getIndexFirstMin(), min(),
					agesStats.getIndexLastMax(), max(),
					agesStats.getIndexFirstMax(), max(),
					agesStats.getIndexLastMax(), average(),
					median());
		}
		return newObject;
	}
}
