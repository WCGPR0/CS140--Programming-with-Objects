/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */
package comparable_person;

public class PersonArrayListStats
{

	/**
	 * Age of the youngest person(s) in the ArrayList
	 */
	int minValue;
	/**
	 * Age of the oldest person(s) in the ArrayList
	 */
	int maxValue;
	/**
	 * The name of the youngest person in the ArrayList that appears first
	 * in the array
	 */
	Person firstMinElement;
	/**
	 * The index in the ArrayList of the first youngest person
	 */
	int indexFirstMin;
	/**
	 * The name of the youngest person that appears last in theArrayList
	 */
	Person lastMinElement;
	/**
	 * The index in the ArrayList of the last youngest person
	 */
	int indexLastMin;
	/**
	 * The name of the oldest person that appears first in the ArrayList
	 */
	Person firstMaxElement;
	/**
	 * The index in the ArrayList of the first oldest person
	 */
	int indexFirstMax;
	/**
	 * The name of the oldest person that appears last in the ArrayList
	 */
	Person lastMaxElement;
	/**
	 * The index in the ArrayList of the last oldest person
	 */
	int indexLastMax;
	/**
	 * Average age of all the Persons
	 */
	double average;
	/**
	 * Median age of all the Persons
	 */
	double median;

	public PersonArrayListStats(int minValue, int maxValue,
			Person firstMinElement, int indexFirstMin,
			Person lastMinElement, int indexLastMin,
			Person firstMaxElement, int indexFirstMax,
			Person lastMaxElement, int indexLastMax,
			double average, double median)
	{
		this.minValue = minValue;
		this.maxValue = maxValue;
		this.firstMinElement = firstMinElement;
		this.indexFirstMin = indexFirstMin;
		this.lastMinElement = lastMinElement;
		this.indexLastMin = indexLastMin;
		this.firstMaxElement = firstMaxElement;
		this.indexFirstMax = indexFirstMax;
		this.lastMaxElement = lastMaxElement;
		this.indexLastMax = indexLastMax;
		this.average = average;
		this.median = median;
		this.toString();
	}

	public String toString()
	{
		return String.format(
				"%s , Min Age: %i, maxValue: %i, First Youngest Name: %s, "
						+ "Index First Min: %i, Last Youngest Name: %s, Last Max Index: %i,"
						+ "Index Last Min: %i, First Oldest Name: %s, Index First Max: %i, Last Oldest Name: %s,"
						+ "Index Last Max: %i, Average Age: %.2d, Median Age: %.2d",
				getClass().getName(), minValue, maxValue,
				firstMinElement, indexFirstMin, lastMinElement,
				indexLastMin, firstMaxElement, indexFirstMax,
				lastMaxElement, indexLastMax, average, median);
	}

}
