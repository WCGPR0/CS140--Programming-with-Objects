package loops_and_arrays;

public class PersonArrayListStats
{

	/**
	 * Age of the youngest person(s) in the ArrayList
	 */
	int minAge;
	/**
	 * Age of the oldest person(s) in the ArrayList
	 */
	int maxAge;
	/**
	 * The name of the youngest person in the ArrayList that appears first
	 * in the array
	 */
	Person firstYoungestName;
	/**
	 * The index in the ArrayList of the first youngest person
	 */
	int indexFirstMin;
	/**
	 * The name of the youngest person that appears last in theArrayList
	 */
	Person lastYoungestName;
	/**
	 * The index in the ArrayList of the last youngest person
	 */
	int indexLastMin;
	/**
	 * The name of the oldest person that appears first in the ArrayList
	 */
	Person firstOldestName;
	/**
	 * The index in the ArrayList of the first oldest person
	 */
	int indexFirstMax;
	/**
	 * The name of the oldest person that appears last in the ArrayList
	 */
	Person lastOldestName;
	/**
	 * The index in the ArrayList of the last oldest person
	 */
	int indexLastMax;
	/**
	 * Average age of all the Persons
	 */
	double averageAge;
	/**
	 * Median age of all the Persons
	 */
	double medianAge;
	
	public PersonArrayListStats(int minAge, int maxAge, Person firstYoungestName,
			int indexFirstMin, Person lastYoungestName,
			int indexLastMin, Person firstOldestName, int indexFirstMax,
			Person lastOldestName,int indexLastMax, double averageAge,
			double medianAge)
	{
		this.minAge = minAge;
		this.maxAge = maxAge;
		this.firstYoungestName = firstYoungestName;
		this.indexFirstMin = indexFirstMin;
		this.lastYoungestName = lastYoungestName;
		this.indexLastMin = indexLastMin;
		this.firstOldestName = firstOldestName;
		this.indexFirstMax = indexFirstMax;
		this.lastOldestName = lastOldestName;
		this.indexLastMax = indexLastMax;
		this.averageAge = averageAge;
		this.medianAge = medianAge;
		this.toString();
	}
	
	public String toString ()
	{
		return String.format("Min Age: %i, MaxAge: %i, First Youngest Name: %s, " +
				"Index First Min: %i, Last Youngest Name: %s, Last Max Index: %i," +
				"Index Last Min: %i, First Oldest Name: %s, Index First Max: %i, Last Oldest Name: %s," +
				"Index Last Max: %i, Average Age: %.2d, Median Age: %.2d", minAge,maxAge,
				firstYoungestName,indexFirstMin,lastYoungestName,indexLastMin,firstOldestName,
				indexFirstMax,lastOldestName,indexLastMax,averageAge,medianAge);
	}

}
