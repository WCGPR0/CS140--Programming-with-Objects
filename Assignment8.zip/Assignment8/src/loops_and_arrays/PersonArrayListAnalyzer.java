package loops_and_arrays;

import java.util.ArrayList;

public class PersonArrayListAnalyzer
{

	  ArrayList<Person> person; // instance variable
	  
	public PersonArrayListAnalyzer(ArrayList<Person> list)
	{
		this.person = list;
	}
	
	public PersonArrayListStats analyze(ArrayList<Person> list)
	{
		 ArrayList<Integer> ages = new ArrayList<Integer>();
		 if (list.size()==0) ages = null;
		 else for (Person age : list)
		 {
			 ages.add(age.getAge());
		 }
		IntListAnalyzer intListAnalyzer = new IntListAnalyzer();
		IntArrayStats agesStats = intListAnalyzer.analyze1(ages);
//Instance Variables
		    int minAge = agesStats.getMinimum();
		    int maxAge = agesStats.getMaximum();
		    double medianAge = agesStats.getMedian();
		    double averageAge = agesStats.getAverage();
		    int firstIndexMax = agesStats.getIndexFirstMax();
		    int firstIndexMin = agesStats.getIndexFirstMin();
		    int lastIndexMax = agesStats.getIndexLastMax();
		    int lastIndexMin = agesStats.getIndexLastMin();

		Person firstYoungestName = null, 
				lastYoungestName = null, 
				firstOldestName = null, 
				lastOldestName = null;
		
		if (firstIndexMin >= 0) {
			firstYoungestName = list.get(firstIndexMin);
		}
		else if (list == null || list.isEmpty())
		{
		firstIndexMax = -1; firstIndexMin = -1; lastIndexMax = -1; lastIndexMin = -1;
		}
		
		    return new PersonArrayListStats(minAge, maxAge, firstYoungestName,
				        firstIndexMin, lastYoungestName, lastIndexMin, firstOldestName,
				        firstIndexMax, lastOldestName, lastIndexMax, averageAge, medianAge);

	} 
}
