/**
 * A creature that resembles a human and has life, strength, and sacks of gold. It's objective is to avoid losing health and obtaining more than 10 sacks of gold. 
 * @author Victor Wu
 * Section 55- CS 140
 */

package old_players;

import java.io.IOException;
import java.io.ObjectStreamClass;
//import java.util.logging.*;
import utility.SingleRandom;

public class Human implements java.io.Serializable
{

  // Instance Class variables
  private String myName;
  private double myHealth;
  private int mySacks;
  private double myStrength;
  public final static double HEALTH_SCALE;
  public final int MAX_HEALTH_POSSIBLE = (int) HEALTH_SCALE;
  public final double MAX_HEALTH;
  public final static double STRENGTH_SCALE;
  public final static int MAX_STRENGTH_POSSIBLE;
  public final double MAX_STRENGTH;
  public final static int NUMBER_SACKS_TO_WIN;
  private int myID = (int)serialVersionUID;
  /**
  * This Human's debug logger
  */
 /* private Logger log; */
  /**
  * Configures logger output file
  */
 /* private Handler handler; */
  private final static long serialVersionUID; 
  /**
   * Static initialization
   */
  static
  {
    serialVersionUID = ObjectStreamClass.lookup(Human.class).getSerialVersionUID();
    STRENGTH_SCALE = 10.0;
    MAX_STRENGTH_POSSIBLE = (int) STRENGTH_SCALE;
    HEALTH_SCALE = 100.0;
    NUMBER_SACKS_TO_WIN = 10;
  }
  // Constructors
  /**
   * Constructs an explicit constructor for a Human object
   * 
   * @param myName
   *          of Human
   * @param mySacks
   *          of sacks for Human
   * @param myHealth
   *          of max and initial health for Human
   * @param myStrength
   *          of Human
   */
  public Human(String myName, int mySacks, double myHealth, double myStrength)
  {
    this.myName = myName;
    this.mySacks = Math.max(Math.min(mySacks, NUMBER_SACKS_TO_WIN), 0);
    this.myStrength = Math.max(Math.min(myStrength, MAX_STRENGTH_POSSIBLE), 1);
    this.myHealth = Math.max(Math.min(myHealth, MAX_HEALTH_POSSIBLE), 1);
    MAX_HEALTH = Math.max(Math.min(myHealth, MAX_HEALTH_POSSIBLE), 1);
    MAX_STRENGTH = Math.max(Math.min(myStrength, MAX_STRENGTH_POSSIBLE), 1);
/*    try
    { 
     handler = new FileHandler("Human" + myID + ".txt");
      handler.setFormatter(new SimpleFormatter());
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    log = Logger.getLogger("Human"+ myID);
    log.addHandler(handler);
   log.setLevel(Level.ALL);
    
    //log.setLevel(Level.OFF);  */    //TURNS LOGGER OFF 
  }

  /**
   * Constructs a partially explicit constructor for a Human object with 0 sacks
   * 
   * @param myName
   *          of Human
   * @param myHealth
   *          of max and initial health for Human
   * @param myStrength
   *          of Human
   */
  public Human(String myName, double myHealth, double myStrength)
  {
    this(myName, 0, myHealth, myStrength);
  }

  /**
   * Constructs a partially explicit constructor for a Human object with 0
   * sacks, random health and strength
   * 
   * @param myName
   *          of Human
   */
  public Human(String myName)
  {
    this(myName, 0, SingleRandom.getInstance().nextInt((int) HEALTH_SCALE),
        SingleRandom.getInstance().nextInt((int) STRENGTH_SCALE));
  }

  /**
   * Constructs a Human named "Anonymous" and has 0 sacks and random health and
   * strength
   */
  public Human()
  {

    this("Anonymous");
  }

  // Accessors
  /**
   * Gets the current name of Human
   * 
   * @return the current name
   */
  public String getName()
  {
    return myName;
  }

  /**
   * Gets the current sacks of Human
   * 
   * @return the current sacks
   */
  public int getSacks()
  {
    return mySacks;
  }

  /**
   * Gets the current strength of Human
   * 
   * @return the current strength
   */
  public double getStrength()
  {
    return myStrength;
  }

  /**
   * Gets the current health of Human
   * 
   * @return the current health
   */
  public double getHealth()
  {
    return myHealth;
  }

  /**
   * Gets the poke power of Human
   * 
   * @return the poke power from formula: strength / HEALTH_SCALE * health
   */
  public double pokeGruman()
  {

    return myStrength / HEALTH_SCALE * myHealth;
  }

  // Predicate methods
  /**
   * Checks if Human has any available sacks
   * 
   * @return the boolean of (sacks > 0)
   */
  public boolean hasSacks()
  {
    return (mySacks > 0);
  }

  /**
   * Checks if Human has any available strength
   * 
   * @return the boolean of (strength > 0)
   */
  public boolean hasStrength()
  {
    return (myStrength > 0);
  }

  /**
   * Checks if Human has any available health
   * 
   * @return the boolean of (health > 0)
   */
  public boolean hasHealth()
  {
    return (myHealth > 0);
  }

  /**
   * Checks the condition to win
   * 
   * @return the boolean of (sacks > NUMBER_SACKS_TO_WIN)
   */
  public boolean hasSacksToWin()
  {
    return (mySacks >= NUMBER_SACKS_TO_WIN);
  }

  // Mutators
  /**
   * Increment sacks by one
   */
  public void incrementSacks()
  {
    mySacks++;
  }

  /**
   * Decrement sacks by one
   */
  public void decrementSacks()
  {
    mySacks--;
  }

  /**
   * Receives damage and loses health and strength
   * 
   * @param force
   *          power of Gruman's terror
   */
  public void sufferTerror(double force)
  {
    myHealth = Math.max(myHealth - force, 0);
    myStrength = Math.max(myStrength - (force / STRENGTH_SCALE), 0);
  }

  /**
   * Adjusts the sacks to a new value
   * 
   * @param mySacks
   *          value to be the new sacks
   */
  public void setSacks(int mySacks)
  {
    this.mySacks = Math.max(Math.min(mySacks, NUMBER_SACKS_TO_WIN), 0);
  }

  /**
   * Adjusts the sacks to a new value
   * 
   * @param myHealth
   *          value to be the new amount for myHealth
   */
  public void setHealth(double myHealth)
  {
    this.myHealth = Math.max(Math.min(myHealth, MAX_HEALTH), 0);
  }

  /**
   * Adjusts the strength to a new value
   * 
   * @param myStrength
   *          value to be the new amount of strength
   */
  public void setStrength(double myStrength)
  {
    this.myStrength = Math.max(Math.min(myStrength, MAX_STRENGTH), 0);
  }

  /**
   * Resets strength to MAX_HEALTH
   */
  public void resetHealth()
  {
    myHealth = MAX_HEALTH;
  }

  /**
   * Resets strength to MAX_STRENGTH
   */
  public void resetStrength()
  {
    myStrength = MAX_STRENGTH;
  }

  /**
   * Adds health by: MAX_HEALTH / HEALTH_SCALE
   */
  public void restoreHealth()
  {
    myHealth = Math.max(
        Math.min(myHealth + (MAX_HEALTH / STRENGTH_SCALE), MAX_HEALTH), 0);
  }

  /**
   * Adds strength by: MAX_STRENGTH / 2*STRENGTH_SCALE
   */
  public void restoreStrength()
  {
    myStrength = Math.max(Math.min(myStrength
        + ((MAX_STRENGTH / 2) / STRENGTH_SCALE), MAX_STRENGTH), 0);
  }

  /**
   * Reduces strength by an additional MAX_STRENGTH / 2*STRENGTH_SCALE
   */
  public void reduceStrength()
  {
    myStrength = Math.max(Math.min(myStrength
        - ((MAX_STRENGTH / 2) / STRENGTH_SCALE), MAX_STRENGTH), 0);
  }

  // Overloaded methods

  /**
   * Gets info about Human
   * 
   * @return Name, Sacks, Strength, Health of the Human
   */
  public String toString()
  {
    return String.format("Name: %s%nSacks: %s%nStrength: %.1f%nHealth: %.1f",
        myName, mySacks, myStrength, myHealth);
  }
}
