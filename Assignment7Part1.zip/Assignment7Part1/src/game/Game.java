/** 
 * The Game outline for basic movements
 * @author Victor Wu
 * Section 55 - CS140
 */

package game;

import java.io.ObjectStreamClass;
import java.util.logging.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import old_players.Gruman;
import old_players.Human;

public class Game // implements java.io.Serializable
{
	// private final static long serialVersionUID;
	public static Logger log;
	/**
	 * Static initialization
	 */
	static
	{
		// serialVersionUID =
		// ObjectStreamClass.lookup(Game.class).getSerialVersionUID();
		log = Logger.getLogger("Game");
	}
	/**
	 * Constant String array with 5 initialized names
	 */
	private final static String[] HUMAN_NAMES =
	{ "someName1", "someName2", "someName3", "someName4", "someName5" };
	/**
	 * An Arraylist of Humans
	 */
	private static ArrayList<Human> someHumans;
	/**
	 * An Arraylist of Grumans
	 */
	private static ArrayList<Gruman> someGrumans;

	public Game()
	{
		setUpLogging();
		someHumans = new ArrayList<Human>();
		someGrumans = new ArrayList<Gruman>();
		for (int i = 0; i < HUMAN_NAMES.length; i++)
		{
			someHumans.add(new Human());
			// someHumans.add(new Human(HUMAN_NAMES[i]));
			someGrumans.add(new Gruman());
			log.info(someHumans.get(i).toString());
			log.info(someGrumans.get(i).toString());
		}

	}

	public int getHumansSize()
	{
		return someHumans.size();
	}

	public int getGrumanSize()
	{
		return someGrumans.size();
	}

	public double attackHuman(int someIndex)
	{
		return someHumans.get(someIndex).pokeGruman();
	}

	public double attackGruman(int someIndex)
	{
		return someGrumans.get(someIndex).terrifyHuman();
	}

	public void defendHuman(int someIndexOfDefend, int someIndexOfAttack,
			double force)
	{
		if (!someHumans.get(someIndexOfDefend).hasStrength()
				&& someHumans.get(someIndexOfDefend).hasSacks())
		{
			someHumans.get(someIndexOfDefend).setSacks(
					someHumans.get(someIndexOfDefend)
							.getSacks() - 1);
			someHumans.get(someIndexOfDefend).restoreHealth();
			winRoundGruman(someIndexOfAttack);
		}
	}

	public void defendGruman()
	{

	}

	public void winRoundHuman(int someIndex)
	{
		someHumans.get(someIndex).setSacks(
				someHumans.get(someIndex).getSacks() + 1);
		someHumans.get(someIndex).restoreHealth();
		someHumans.get(someIndex).reduceStrength();
	}

	public void winRoundGruman(int someIndex)
	{
		someGrumans.get(someIndex).setSacks(
				someGrumans.get(someIndex).getSacks() + 1);
		someGrumans.get(someIndex).restoreHealth();
		someGrumans.get(someIndex).reduceStrength();
	}

	public static void setUpLogging()
	{
		/*
		 * try { handler = new FileHandler("Human" + myID + ".txt");
		 * handler.setFormatter(new SimpleFormatter()); } catch
		 * (IOException e) { e.printStackTrace(); } log =
		 * Logger.getLogger("Human"+ myID); log.addHandler(handler);
		 * log.setLevel(Level.ALL);
		 * 
		 * //log.setLevel(Level.OFF);
		 */// TURNS LOGGER OFF
	}

	public String toString()
	{
		return someHumans.toString() + someGrumans.toString();
	}
}
