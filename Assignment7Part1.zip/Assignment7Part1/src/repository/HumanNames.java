/** 
 * A subclass of the Names for the Humans
 * @author Victor Wu
 * Section 55 - CS140
 */

package repository;

public class HumanNames extends Names
{
	private static final String[] GRUMAN_NAMES =
	{ "Thutmose", "Darius", "Alexander", "Ch'in", "Pompey", "Julius",
			"Atilla", "Charlemagne", "Hrorekr", "Genghis",
			"Napoleon", "Naughty" };

	private static HumanNames instance;
	static
	{
		instance = new HumanNames();
	}

	private HumanNames()
	{
		super(GRUMAN_NAMES);
	}

	/**
	 * Method that returns the Instance of this class
	 * 
	 * @return current instance
	 */
	public static HumanNames getInstance()
	{
		return instance;
	}
}
