/** 
 * A subclass of the Names for Grumans
 * @author Victor Wu
 * Section 55 - CS140
 */

package repository;

public class GrumanNames extends Names
{
	private static final String[] GRUMAN_NAMES =
	{ "Aggravating Gruman", "Vextious Gruman", "Bothersome Gruman",
			"Hazardous Gruman", "Disturbing Gruman" };
	private static GrumanNames instance;
	static
	{
		instance = new GrumanNames();
	}

	private GrumanNames()
	{
		super(GRUMAN_NAMES);
	}

	/**
	 * Method that returns the Instance of this class
	 * 
	 * @return current instance
	 */
	public static GrumanNames getInstance()
	{
		return instance;
	}
}
