/** A bank account that holds values
 * Class invariants: getBalance() > 0;
 */
package bank.main;

/** 
 * A BankAccount that uses the Bank to hold values
 * @author Victor Wu
 * Section 55 - CS140
 */

public class BankAccount
{
/**
 * The current balance  
 */
  private double balance;
  
  /**
   * The current name
   */
  private String name;
  
  /**
   * Static counter that keeps track of the amounts of BankAccounts created
   */
  private static int counter;
  
/**
 * Default constructor that initializes balance as 0 and name as "Anonymous"  
 */
  
  public BankAccount()
  {   
    this(0, "Anonymous");
  }
  
  
 /**
  * Partially explicit constructor that sets a balance to a value
  * @param initialBalance the value that balance gets set to
  */
  
  public BankAccount(double balance)
  {   
this(balance, "Anonymous");
  }
  
  /**
   * Partially explicit constructor that sets a balance to a value and name
   * @param initialBalance the value that balance gets set to
   * @param name the name to be set as
   */
   
   public BankAccount(double balance, String name)
   {   
     this.balance = balance;
     this.name = name;
   }
  

  /**
   *  Gets the current balance of this bank account
   *  @return current balance
   */
  public double getBalance()
  {   
    return balance;
  }


  /**
   *  Gets the name of this bank account
   *  @return name
   */
  public String getName()
  {   
    return name;
  }

  /**
   *  Gets the current counter
   *  @return counter
   */
  public static int getCounter()
  {   
    return counter;
  }
  
  /**
   * Adds to the current balance
   * @param amount the amount to add to the balance
   */
  
  public void deposit(double amount)
  {  
    balance += amount;
  }
  
  /**
   * Adds to the current counter
   */
  
  private static void incrementCounter()
  {  
counter++;
  }
  
  /**
   * Takes out from the current balance
   * @param amount the amount to remove from the balance
   */
  
  public void withdraw(double amount)
  { 
    balance = balance - Math.min(Math.abs(amount),balance); //The maximum to withdraw is the balance;
  }  
  
  public boolean hasBalance()
  {
    return (balance!=0);
  }
}


