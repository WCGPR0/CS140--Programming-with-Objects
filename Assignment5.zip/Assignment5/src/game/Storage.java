package game;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

/**
 * This class provides object file I/O services for the Game class
 *
 */
public class Storage
{  
	//-- Class variables for debugging ------------------------------------------

  /**
   * Logger object for debugging
   */
  public static Logger log;
  static
  {
    log = Logger.getLogger("Storage");
  }  
  
  //-- Instance Variables -----------------------------------------------------
 
  /**
   * Virtual file object
   */
  //Declare a virtual file object (you can call it file)
  File file;
  //-- Methods ----------------------------------------------------------------  

  //-- Constructors -----------------------------------------------------------

  /**
   * Responsibility: Creates a Storage object 
   */
  public Storage()
  {
    setUpLogging();
    //Initialize file to null
    file = null;
  }
  
  //-- Class (Helper) methods -------------------------------------------------
 
  /**
   * Responsibility: Turns logging on when desired 
   */
  private static void setUpLogging()
  {
    log.setLevel(Level.ALL);     
    //log.setLevel(Level.OFF);
  }  

  //------ Instance methods ---------------------------------------------------
  //-- Predicates -------------------------------------------------------------

  /**
   * Responsibility: Determines if file has been selected
   * @return true if present, false otherwise
   */  
  public boolean hasFile()
  {
    //Place your code here
    return file.exists();
  }

  //-- Accessors --------------------------------------------------------------
      
  /**
   * Responsibility: reads in game from file
   * @return game to be loaded
   */
  public Game read()
  {
    //Note structure of exception-handling!
    
    //Set game to null
    Game game = null;
    //Will read in entire game object at a time
    //Declare an object of the ObjectInputStream class and set it to null
    ObjectInputStream inObjectStream = null;
    try 
    {
    	//Note decorator pattern: 
      //  low-level stream wraps file, high-level stream wraps low-level stream
      
      //Declare and instantiate an object of the FileInputStream class, 
      FileInputStream fiStream = new FileInputStream(file);
      //  sending it the file instance variable as an argument
      //Instantiate hi-level Object stream, sending low-level stream as argument
      inObjectStream = new ObjectInputStream(new FileInputStream(file));
      //Set game to result of reading in object from Object stream --
      //  don't forget to cast from Object to Game
      game = (Game) inObjectStream.readObject();
      try
      {   
      	//leave blank
      }
      finally //Close stream if created
      {
        //close Object stream if it isn't null  
        if(inObjectStream != null)
        {
          inObjectStream.close();
        }
      }      
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
      System.out.println(e.getCause());
      JOptionPane.showMessageDialog
                  (null, "Read failed:  not a valid Game file");
    } 
    catch (IOException e)
    {
        e.printStackTrace();
        System.out.println(e.getCause());
        JOptionPane.showMessageDialog(null, "Open failed:  IOException");
    }
    //return game object
    return game;
  }

  /**
   * Responsibility: Returns state of storage object
   * @return formatted String description of file
   */ 
  public String toString()
  {
    return file!=null ? 
    			 "\nFile is:  " + file.toString() : "\nFile is undefined";
  }
   
  //-- Mutators ---------------------------------------------------------------

  /**
   * Responsibility: Allows user to select file to open
   * using JFileChooser
   */
  public void setOpenFile() 
  {  
    //Set file to null
    file = null;
    //Declare and instantiate object of JFileChooser class
    JFileChooser chooser = new JFileChooser();
    //Set the mode of the chooser dialog to FILES_ONLY
    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    //Set the title of the dialog to "Open"
    chooser.setDialogTitle("Open");
    //Display the dialog box (showOpenDialog())and store the option selected
    int option = chooser.showOpenDialog(chooser);
    //If the user has chosen APPROVE_OPTION
    if (option == JFileChooser.APPROVE_OPTION)
    {
    //  Set the instance variable file to the selected file
      file = chooser.getSelectedFile();
    }
    //If we don't have the file, bring up a message box that says so
    if(!file.exists())
    {
      JOptionPane.showMessageDialog(chooser, 
          "We don't have the file!");
    }
  }
  
  /**
   * Responsibility: Allows user to select file to write to
   * using JFileChooser
   */  
  public void setSaveFile()
  {
    //Set the file instance variable to null
    file = null;
    //Declare and instantiate object of JFileChooser class
    JFileChooser chooser = new JFileChooser();
    //Set the mode of the chooser dialog to FILES_ONLY
    chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
    //Set the title of the dialog to "Save"
    chooser.setDialogTitle("Save");
    //Display the dialog box (showOpenDialog())and store the option selected
    int option = chooser.showSaveDialog(chooser);
    //If the user has chosen APPROVE_OPTION
    if(option == JFileChooser.APPROVE_OPTION) 
    {
    //  Set the instance variable file to the selected file
      File file = chooser.getSelectedFile();
    //If we don't have the file, bring up a message box that says so
      if(file == null)
      {
        JOptionPane.showMessageDialog(chooser, 
            "The file is null!");
      }
    }
  }
    
  /**
   * Responsibility:  Writes game to file
   * @param game - game to be saved in file
   */ 
  public void write(Game game)
  {
    //Will write entire game object at a time
    //Declare an object of the ObjectOutputStream class and set it to null
    ObjectOutputStream outObjectStream = null;
    try
    {
    	//Note decorator pattern:
      //  low-level stream wraps file, high-level stream wraps low-level stream
      
      //Declare and instantiate an object of the FileOutputStream class, 
      //  sending it the file instance variable as an argument
      FileOutputStream fos = new FileOutputStream(file);
      //Instantiate hi-level Object stream, sending low-level stream as argument
      outObjectStream = new ObjectOutputStream(new FileOutputStream(file));
      //Write game object to file using writeObject() method 
      outObjectStream.writeObject(game);
      try
      {
        //Leave blank
      }
      finally  
      {
        //Close Ouptput stream if it isn't null
        if(outObjectStream != null)
        {
          outObjectStream.close();
        }
      }
    }
    catch (IOException e)
    {
      e.printStackTrace();
      System.out.println(e.getCause());
      JOptionPane.showMessageDialog(null, "Save failed:  IOException");
    }
  }
}