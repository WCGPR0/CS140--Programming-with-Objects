/**
 * This class contains names for the Gruman class to use. 
 * @author Victor Wu
 * Section 55- CS 140
 * Lab 3
 */

package repository;

import java.io.ObjectStreamClass;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import players.Gruman;
import utility.SingleRandom;

public class Names implements java.io.Serializable
{
  // Constant and static variables
  /**
   * The string array of some preset Gruman names
   */
  private static final String[] GRUMAN_NAMES = { "Aggravating Gruman",
      "Vextious Gruman", "Bothersome Gruman", "Hazardous Gruman",
      "Disturbing Gruman" };
  /**
   * The amount of names in GRUMAN_NAMES
   */
  private static final int GRUMAN_NAMES_LENGTH;
  // Static variables
  /**
   * A private instance of this class
   */
  private static Names instance;
  private final static long serialVersionUID; 
/**
 * Static intialization
 */
  static
  {
    instance = new Names();
    serialVersionUID = ObjectStreamClass.lookup(Names.class).getSerialVersionUID();
    GRUMAN_NAMES_LENGTH = GRUMAN_NAMES.length;
  }
  /**
   * An Arraylist object
   */
  private static ArrayList<String> grumanNames;

  /**
   * Default constructor that constructs the Arraylist as array GRUMAN_NAMES
   */
  private Names()
  {
    grumanNames = new ArrayList(Arrays.asList(GRUMAN_NAMES));
  }

  // Accessors
  /**
   * Method that returns number of names in the array
   * 
   * @return an int of GRUMAN_NAMES_LENGTH
   */

  public int getMaxNamesToStart()
  {
    return GRUMAN_NAMES_LENGTH;
  }

  /**
   * Method that returns number of names in the ArrayList
   * 
   * @return an int of size grumanNames
   */
  public int getCurrentNumberOfNames()
  {
    return grumanNames.size();
  }

  /**
   * Method when given an index, returns the name at that index
   * 
   * @param the
   *          index for the element of grumanNames
   * @return the String element found in grumanNames
   */
  public String getName(int someIndex)
  {
    return grumanNames.get(someIndex);
  }

  /**
   * Method when given a name, returns the index of that name
   * 
   * @param a
   *          String that will be searched in grumanNames
   * @return the index number of the matching String in grumanNames with the
   *         parameter, else it'll return -1
   */
  public int findName(String someName)
  {
    for (int i = 0; i < grumanNames.size(); i++)
    {
      if (grumanNames.get(i) == someName)
        return i;
    }
    return -1;
  }

  /**
   * Method when given a name, returns whether or not the name is in the
   * grumanNames
   * 
   * @param a
   *          String that will be searched in the grumanNames
   */
  public boolean hasName(String someName)
  {
    for (int i = 0; i < grumanNames.size(); i++)
    {
      if (grumanNames.get(i) == someName)
        return true;
    }
    return false;
  }

  /**
   * Method that returns whether or not there are any names in grumanNames
   * 
   * @return true if grumanNames is not empty, else false
   */
  public boolean hasNames()
  {
    for (int i = 0; i < grumanNames.size(); i++)
    {
      if (grumanNames.get(i) != "")
        return true;
    }
    return false;
  }

  /**
   * Method that randomly returns a name found in grumanNames, and removes it
   * from the grumanNames, else resets it
   * 
   * @return a random String name in Arraylist
   */
  public String takeNames()
  {
    if (this.hasNames())
    {
      int tempInt = SingleRandom.getInstance().nextInt(grumanNames.size());
      String tempString = grumanNames.get(tempInt);
      grumanNames.remove(tempInt);
      return tempString;
    }
    else
      this.resetNames();
    return null;
  }

  /**
   * Method that returns a string containing all the names currently in the
   * ArrayList
   */
  public String toString()
  {
    return grumanNames.toString();
  }

  /**
   * Method that returns the Instance of this class
   * 
   * @return current instance
   */
  public static Names getInstance()
  {
    return instance;
  }

  // Mutators
  /**
   * Method when given a name, adds the name to the ArrayList
   * 
   * @param a
   *          String to be added
   */
  public void addName(String someName)
  {
    grumanNames.add(someName);
  }

  /**
   * Method when given an index and a new name, replaces the old name at the
   * given index of the ArrayList with the new name
   * 
   * @param an
   *          int for the index of the element to be replaced
   * @param a
   *          String to replace the old String
   */
  public void replaceName(int someIndex, String someName)
  {
    grumanNames.set(someIndex, someName);
  }

  /**
   * Method when given an old name that is in the ArrayList and a new name,
   * replace the old name in the ArrayList with the new name
   * 
   * @param a
   *          String that will be searched in the grumanNames
   * @param a
   *          String that will replace the old String
   */
  public void replaceName(String someOldName, String someNewName)
  {
    grumanNames.set(this.findName(someOldName), someNewName);
  }

  /**
   * Method that removes all the names in the ArrayList
   */

  public void eraseNames()
  {
    grumanNames.clear();
  }

  /**
   * Method that re-instantiate the names ArrayList and initialize it to the
   * gruman names in the arrray
   */

  public void resetNames()
  {
    grumanNames = new ArrayList(Arrays.asList(GRUMAN_NAMES));
  }

}
