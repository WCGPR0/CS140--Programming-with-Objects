/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */

package loops_and_arrays;

public class intArrayStats
{
	/**
	 * The smallest value in the array
	 */
	private int minimum;
	/**
	 * The largest value in the array
	 */
	private int maximum;
	/**
	 * The smallest array index where the minimum occurs
	 */
	private int firstMinIndex;
	/**
	 * The largest array index where the minimum occurs
	 */
	private int lastMinIndex;
	/**
	 * The smallest array index where the maximum occurs
	 */
	private int firstMaxIndex;
	/**
	 * The largest array index where the maximum occurs
	 */
	private int lastMaxIndex;
	/**
	 * The average of all the values in the array
	 */
	private double average;
	/**
	 * The center value of the sorted array if array length is odd OR
	 * average of the 2 center values if the array length is even
	 */
	private double median;

	public intArrayStats(int minimum, int maximum, int firstMinIndex,
			int lastMinIndex, int firstMaxIndex, int lastMaxIndex,
			double average, double median)
	{
		this.minimum = minimum;
		this.maximum = maximum;
		this.firstMinIndex = firstMinIndex;
		this.lastMinIndex = lastMinIndex;
		this.firstMaxIndex = firstMaxIndex;
		this.average = average;
		this.median = median;
		this.toString();
	}
}
