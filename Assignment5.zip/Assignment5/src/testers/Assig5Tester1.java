/**
 * @author Victor Wu
 * CS 140 - B55
 * Assignment 5
 */

package testers;

import loops_and_arrays.*;

public class Assig5Tester1
{

	public static void main(String[] args)
	{
		int[] array1 = null;
		int[] array2;
		int[] array3 = new int[20];
		int[] array4 = new int[21];
		IntArrayAnalyzer someIntArrayAnalyzer = new IntArrayAnalyzer();

		System.out.println(someIntArrayAnalyzer.analyze1(array1));
		// System.out.println(someIntArrayAnalyzer.analyze1(array2));
		System.out.println(someIntArrayAnalyzer.analyze1(array3));
		System.out.println(someIntArrayAnalyzer.analyze1(array4));
		System.out.println(someIntArrayAnalyzer.analyze2(array1));
		// System.out.println(someIntArrayAnalyzer.analyze2(array2));
		System.out.println(someIntArrayAnalyzer.analyze2(array3));
		System.out.println(someIntArrayAnalyzer.analyze2(array4));
	}
}
