package bank.units_tests;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import bank.main.BankAccount;


public class BankAccountUnitTest
{
 @BeforeClass
  public static void setUpClass()
  {
    assertEquals(
        "Before creating an account, counter is 0", 
        0, BankAccount.getCounter() );
    BankAccount account1 = new BankAccount();
    assertEquals(
        "Before creating an account, counter is 1", 
        1, account1.getCounter() );
  }
@Before
public void setUp() throws Exception
{
  
}
 
  @Test
  public void testBankAccount()
  {
    BankAccount account = new BankAccount();
    assertEquals(
        "Balance of account created by first constructor should be 0", 
        0.0, 
        account.getBalance(), 
        0.001);//last argument is acceptable error for floating type
  }

  @Test
  public void testBankAccountDouble()
  {
    BankAccount account = new BankAccount(100.50);
    assertEquals(
        "Balance of account created by first constructor should be 100.5", 
        100.5, 
        account.getBalance(), 
        0.001);//last argument is acceptable error for floating type
  }

  @Test
  public void testBankAccountDoubleString()
  {
    BankAccount account = new BankAccount(9000,"Victor");
    assertEquals(
        "Balance of account created by first constructor should be 9000", 
        9000, 
        account.getBalance(), 
        0.001);//last argument is acceptable error for floating type
    assertEquals(
        "Name of account created by first constructor should be \"Victor\"", 
        "Victor", 
        account.getName());//last argument is acceptable error for floating type
  }

  @Test
  public void testGetBalance()
  {
    BankAccount account = new BankAccount(100.0);
    assertEquals(
        "A valid getBalance should get the balance correctly", 
        100, 
        account.getBalance(), 
        .001);//last argument is acceptable error for floating type
  }

  @Test
  public void testGetName()
  {
    BankAccount account = new BankAccount();
    assertEquals(
        "Name of account created by first constructor should be \"Anonymous\"", 
        "Anonymous", 
        account.getName());//last argument is acceptable error for floating type
  }

  @Test
  public void testDeposit()
  {
    BankAccount account = new BankAccount(100.0);
    account.deposit(50.5);
    assertEquals(
        "A valid deposit should add to the balance correctly", 
        150.5, 
        account.getBalance(), 
        .001);//last argument is acceptable error for floating type
  }

  @Test
  public void testWithdraw()
  {
    BankAccount account = new BankAccount(100.0);
    account.withdraw(50.5);
    assertEquals(
        "A valid withdrawal should reduce the balance correctly", 
        49.5, 
        account.getBalance(), 
        .001);
    account.withdraw(100.5);
    assert account.getBalance() >= 0;
    
  }

  @Test
  public void testHasBalance()
  {
    BankAccount account = new BankAccount(0);
    assertEquals(
        "A valid hasBalance should return false with no balance", 
        false, 
        account.hasBalance()
        );
  }

}
